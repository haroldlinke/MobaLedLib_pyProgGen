# 1 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\DCCInterface.cpp"
/*

 MobaLedLib: LED library for model railways

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



 Copyright (C) 2018 - 2020  Hardi Stengelin: MobaLedLib@gmx.de

 this file: Copyright (C) 2020 Jürgen Winkler: MobaLedLib@a1.net



 This library is free software; you can redistribute it and/or

 modify it under the terms of the GNU Lesser General Public

 License as published by the Free Software Foundation; either

 version 2.1 of the License, or (at your option) any later version.



 This library is distributed in the hope that it will be useful,

 but WITHOUT ANY WARRANTY; without even the implied warranty of

 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU

 Lesser General Public License for more details.



 You should have received a copy of the GNU Lesser General Public

 License along with this library; if not, write to the Free Software

 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA

 -------------------------------------------------------------------------------------------------------------





 DCC rail signal decoder for ESP with thread save read buffer      18.10.2020 Jürgen

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~





 Documents:

 ~~~~~~~~~~

 - https://www.opendcc.de/info/dcc/dcc.html

 - https://www.nmra.org/sites/default/files/s-9.2.1_2012_07.pdf

 - https://www.nmra.org/sites/default/files/s-92-2004-07.pdf

 - https://lastminuteengineers.com/handling-esp32-gpio-interrupts-tutorial/

 - https://randomnerdtutorials.com/esp32-pinout-reference-gpios/



Revision History :

~~~~~~~~~~~~~~~~~

18.10.20:  Versions 1.0 (Jürgen)

*/
# 1 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
/*

 MobaLedLib: LED library for model railways

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



 Copyright (C) 2018 - 2020  Hardi Stengelin: MobaLedLib@gmx.de



 This library is free software; you can redistribute it and/or

 modify it under the terms of the GNU Lesser General Public

 License as published by the Free Software Foundation; either

 version 2.1 of the License, or (at your option) any later version.



 This library is distributed in the hope that it will be useful,

 but WITHOUT ANY WARRANTY; without even the implied warranty of

 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU

 Lesser General Public License for more details.



 You should have received a copy of the GNU Lesser General Public

 License along with this library; if not, write to the Free Software

 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA

 -------------------------------------------------------------------------------------------------------------





 Autogenerate program for the LEDs Arduino                                                 by Hardi   04.09.19:

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 The excel program Prog_Generator_MobaLedLib.xlsm is a graphical user interface for the MobaLedLib.

 It could generate the program to control LEDs and other WS281x components without programming

 knowledge. The user simply fills a table with all wanted functions and start the "Send to Arduino"

 button. The Excel program generates the header file "LEDs_AutoProg.h" which is linked together

 with this program and send to the nano.



 This program could read commands from a railway central using DCC, Selectrix or CAN.



 The Excel program is opened by copying the following line into the address bar of

 Windows Explorer:

 %USERPROFILE%\Documents\Arduino\libraries\Mobaledlib\examples\23_B.LEDs_AutoProg\Prog_Generator_MobaLedLib.xlsm









 Hardware:

 ~~~~~~~~~



 - DCC or Selectrix:    (CAN Bus see below)

   ~~~~~~~~~~~~~~~~~

   The project is used with two two Arduino compatible boards (Uno, Nano, Mega, ...) if the

   commands are read from DCC or Selectrix.

   For DCC an opto coppler (6N137), a diode (1n148) and a 1K resistor is needed.

   For Selectrix two 22K resistors and a DIN5 connector is needed.



   The two Arduinos are connected by three wires (TX1-RX1, GND, A1).

   The A1 line is used to disable the serial transmission while the LEDs are updated.



   The DIN pin of the first LED is connected to pin D6 (LED_DO_PIN).

   An optional heartbeat LED could be connected to pin D3 togeter with a 470 ohm resistor.



                       .-----------------------------------------------------.

                       |         DCC or Selectrix                            |  The DCC or Selectrix program

 Optocopler is         |           Arduino Nano: +-----+                     |  must be sendto the Arduino

 used for DCC          |            +------------| USB |------------+        |  at first to make sure that the

 only              +5V |            |            +-----+            |        |  TX line is disabled. Otherwise

                    ^  |            | [ ]D13/SCK        MISO/D12[ ] |        |  the LED Arduino can't be flashed

            ______  |  |            | [ ]3.3V           MOSI/D11[ ]~|        |

           |1     |-'  |            | [ ]V.ref     ___    SS/D10[ ]~|        |

 ---[1K]---|      |    |            | [ ]A0       / N \       D9[ ]~|        |

 t      .--|      |----'  .---------| [ ]A1      /  A  \      D8[ ] |        |

 o      |  |______|-.     |         | [ ]A2      \  N  /      D7[ ] |        |            Selectrix DIN5 connector

        |   6N137   |     |         | [ ]A3       \_0_/       D6[ ]~|        *----[22K]---- Pin 1

 r      |          GND    |         | [ ]A4/SDA               D5[ ]~|        |              Pin 2 --- GND

 a     \/ 1N148           |         | [ ]A5/SCL               D4[ ] |-------------[22K]---- Pin 4

 i     --                 |    +5V  | [ ]A6              INT1/D3[ ]~|-HB LED | with 470 ohm resistor (Opt.)

 l      |                 |     ^   | [ ]A7              INT0/D2[ ] |--------'

 -------'                 |     '---| [ ]5V                  GND[ ] |

                          |         | [ ]RST                 RST[ ] |

                          |  .-GND--| [ ]GND   5V MOSI GND   TX1[ ] |--------*---[3.9K]--.

                          |  |      | [ ]Vin   [ ] [ ] [ ]   RX1[ ] |        |           |

                          |  |      |          [ ] [ ] [ ]          |        |          GND

                          |  |      |          MISO SCK RST         |        |

                          |  |      | NANO-V3                       |        |

                          |  |      +-------------------------------+        |

                          |  |                                               |

                          |  |                                               |

                          |  | LED-Arduino Nano: +-----+                     |

                          |  |      +------------| USB |------------+        |

                          |  |      |            +-----+            |        |

                          |  |      | [ ]D13/SCK        MISO/D12[ ] |        |

                          |  |      | [ ]3.3V           MOSI/D11[ ]~|        |

                          |  |      | [ ]V.ref     ___    SS/D10[ ]~|        |  <== This second program must be send

                          |  |      | [ ]A0       / N \       D9[ ]~|        |      to the LED-Arduino

          SEND_DISABLE -> '---------| [ ]A1      /  A  \      D8[ ] |        |      (23_B.DCC_Rail_Decoder_Receiver.ino)

          line               |      | [ ]A2      \  N  /      D7[ ] |        |

                             |      | [ ]A3       \_0_/       D6[ ]~|---LEDs | WS281x

                             |      | [ ]A4/SDA               D5[ ]~|        |

                             |      | [ ]A5/SCL               D4[ ] |        |

                             | +5V  | [ ]A6              INT1/D3[ ]~|        |

                             |  ^   | [ ]A7              INT0/D2[ ] |        |

                             |  '---| [ ]5V                  GND[ ] |        |

                             |      | [ ]RST                 RST[ ] |        |

                             '-GND--| [ ]GND   5V MOSI GND   TX1[ ] |        |

                                    | [ ]Vin   [ ] [ ] [ ]   RX1[ ] |--------'

                                    |          [ ] [ ] [ ]          |

                                    |          MISO SCK RST         |

                                    | NANO-V3                       |

                                    +-------------------------------+

   The +5V supply lines of both arduinos could be connected together if they are powerd from one power supply (one USB).





 - CAN Bus:

   ~~~~~~~

   If the program is used with the Maerklin CAN bus only one Arduino compatible board (Uno, Nano, Mega, ...)

   and a MCP2515 CAN Module is needed (~1.50 Eu Google: "mcp2515 CAN Module China").



   The DIN pin of the WS2811 module is connected to pin D6 (LED_DO_PIN).



     .-----------------------------------------------------.

     | Arduino Nano:    +-----+                            |  +--------------------+

     |     +------------| USB |------------+               |  |INT MCP2515 CAN     |

     |     |            +-----+            |               '--|SCK  ____           |

     '--B5-| [ ]D13/SCK        MISO/D12[ ] |---B4-----\/------|SI- |    |CAN     .-|

           | [ ]3.3V           MOSI/D11[ ]~|---B3-----/\------|SO- |    |      H |o|--- CAN H   to the Maerklin MS2

           | [ ]V.ref     ___    SS/D10[ ]~|---B2-------------|CS- |    |      : |o|--- CAN L   Attention: The CAN bus to the MS2 must be isolated !

        C0 | [ ]A0       / N \       D9[ ]~|   B1             |GND |____|      L '-|            Otherwise the components may be damaged.

        C1 | [ ]A1      /  A  \      D8[ ] |   B0         +5V-|VCC            .. J1|            It's also possible to use a common ground.

        C2 | [ ]A2      \  N  /      D7[ ] |   D7             +--------------------+

        C3 | [ ]A3       \_0_/       D6[ ]~|---D6------> LEDs WS281x                            Don't connect the Arduino ground with one

        C4 | [ ]A4/SDA               D5[ ]~|   D5                                               of the rails!

        C5 | [ ]A5/SCL               D4[ ] |   D4

           | [ ]A6              INT1/D3[ ]~|   D3

           | [ ]A7              INT0/D2[ ] |   D2

  +5V------| [ ]5V                  GND[ ] |

        C6 | [ ]RST                 RST[ ] |   C6

  GND------| [ ]GND   5V MOSI GND   TX1[ ] |   D0

           | [ ]Vin   [ ] [ ] [ ]   RX1[ ] |   D1

           |          [ ] [ ] [ ]          |

           |          MISO SCK RST         |

           | NANO-V3                       |

           +-------------------------------+





 Adapter to connect the ESP32 to the Mainboard

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

 ESP32    LED / DCC Arduino

 4        D3         LED 1 (Left   switch)

 14       D4         LED 2 (Middle switch)

 15       D5         LED 3 (Right  switch)

 27       D6         LED Bus0

 12       D7         Left   switch

 26       D8         Middle switch

 25       D9         Right  switch

 32       A4         LED Bus 1

 13             D2   DCC Signal



 ToDo: Define the other pins







 Revision History:

 ~~~~~~~~~~~~~~~~~

 12.01.20:  - Improved the Check_Mainboard_Buttons() function

 01.05.20:  - Storing the status to the EEPROM (Functions from Juergen)

 05.05.20:  - Wait 1.5 seconds after booting to prevent flickering of the LEDs if the Arduino is detected from the excel program

 13.05.20:  - Started the SPI interface

 17.05.20:  - The SPI communication is no longer necessary since the TX LED Problem could also be

              solved wit a 3.9K resistor between TX and ground.

              The SPI functions are kept in the software but the are normally disabled by not defining USE_SPI_COM

 05.10.20:  - Added the Mainboard LED function

 07.10.20:  - Added DayAndNight Timer

 08.10.20:  - New method "LED_to_Var()" to set variables controlled by the LED values.

 09.10.20:  - Using port writes to speed up the Mainboard_LED function

            - Added additional pins to the Mainboard_LED function. Now nearly every pin could be

              used as LED pin (New channels 0, 5-16). See definition of the LEDx_PINs below

 10.10.20:  - Added the compiler switch "KeepDarknessCtr"

 11.10.20:  - New Mainboard_LED defines which end with the pin number (Example: Mainboard_LED_A0)

 14.11.20:  - Added the experimental ESP32 support

*/
# 177 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
# 178 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 2
# 207 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                               // The programm also sends a command to the DCC/SX slave to deactivate his pins
# 247 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
/*

Abhaengig von der Konfiguration braucht die alte oder die neue Variante mehr Speicher



Sheet: MB Test 2 KEYBRD

Ohne USE_SWITCH_AND_LED_ARRAY

Der Sketch verwendet 19598 Bytes (60%) des Programmspeicherplatzes. Das Maximum sind 32256 Bytes.

Globale Variablen verwenden 672 Bytes (32%) des dynamischen Speichers, 1376 Bytes für lokale Variablen verbleiben. Das Maximum sind 2048 Bytes.



Mit USE_SWITCH_AND_LED_ARRAY

Der Sketch verwendet 19650 Bytes (60%) des Programmspeicherplatzes. Das Maximum sind 32256 Bytes.

Globale Variablen verwenden 672 Bytes (32%) des dynamischen Speichers, 1376 Bytes für lokale Variablen verbleiben. Das Maximum sind 2048 Bytes.

                     -52



Sheet: MB Test 3 KEY_80

Ohne USE_SWITCH_AND_LED_ARRAY

Der Sketch verwendet 19914 Bytes (61%) des Programmspeicherplatzes. Das Maximum sind 32256 Bytes.

Globale Variablen verwenden 672 Bytes (32%) des dynamischen Speichers, 1376 Bytes für lokale Variablen verbleiben. Das Maximum sind 2048 Bytes.



Mit USE_SWITCH_AND_LED_ARRAY

Der Sketch verwendet 19892 Bytes (61%) des Programmspeicherplatzes. Das Maximum sind 32256 Bytes.

Globale Variablen verwenden 672 Bytes (32%) des dynamischen Speichers, 1376 Bytes für lokale Variablen verbleiben. Das Maximum sind 2048 Bytes.

                     22

*/
# 319 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
CRGB leds[242 /* Number of LEDs (Maximal 256 RGB LEDs could be used)*/]; // Define the array of leds





  uint8_t Config_RAM[24/2]; /* RAM used for the configuration functions. The size is calculated in the macros which are used in the Config[] table.*/ MobaLedLib_C MobaLedLib(leds, sizeof(leds)/sizeof(CRGB), Config, Config_RAM, sizeof(Config_RAM), 
# 325 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3 4
 __null
# 325 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
 ); /* MobaLedLib_C class definition*/; // Define the MobaLedLib instance





  LED_Heartbeat_C LED_HeartBeat(13 /* Build in LED*/); // Initialize the heartbeat LED which is flashing if the program runs.





  char Buffer[1][13] = {""};
# 350 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
bool Send_Disable_Pin_Active = 1; // 13.05.20:
# 359 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
//-------------------------------------
void Proc_Color_Cmd(const char *Buffer) // 03.11.19:
//-------------------------------------
{
  int Led, r, g, b, Leds, cnt;
  // #Lll rr gg bb nn
  if ((cnt = sscanf(Buffer, "L %x %x %x %x %x", &Led, &r, &g, &b, &Leds)) == 5)
       {
       //Serial.print("#L:"); Serial.print(Led);Serial.print(" r="); Serial.print(r); Serial.print(" g="); Serial.print(g); Serial.print(" b="); Serial.print(g); Serial.print(" Leds="); Serial.println(Leds);
       for (int i = Led; i <= 255 && i < Led+Leds; i++)
           {
           leds[i].r = r;
           leds[i].g = g;
           leds[i].b = b;
           }
       FastLED.show(); // Show the LEDs (send the leds[] array to the LED stripe)
       }
  else { Serial.print((reinterpret_cast<const __FlashStringHelper *>(
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                     (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                     "#Wrong Cnt:'"
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                     ); &__c[0];}))
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                     ))); Serial.print(Buffer); Serial.print((reinterpret_cast<const __FlashStringHelper *>(
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                                            (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                                            "':"
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                                            ); &__c[0];}))
# 376 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                                            ))); Serial.println(cnt); }

  //Serial.println(Buffer); //
}

void (* ResetArduino)(void) = 0; // Restart the Arduino





//--------------------------------
void Receive_LED_Color_per_RS232() // 03.11.19:
//--------------------------------
{

  if (Send_Disable_Pin_Active) digitalWrite(A1 /* Pin A1 is used to stop the DCC, Selectrix, ... Arduino from sending RS232 characters*/, 1); // Tell the DCC Arduino to be quiet         // 13.05.20:  Added: if (Send_Disable_Pin_Active)


  char Buffer[20] = "";
  uint8_t JustStarted = 1;
  while (1)
     {

       LED_HeartBeat.Update(300); // Fast Flash

     if (Serial.available() > 0)
        {
        char c = Serial.read();
        switch (c)
           {
           case '#': *Buffer = '\0'; break;
           case '\n': // Proc buffer       (For tests with the serial console of Arduino use "Neue Zeile" and not "..(CR)" )
                      if (JustStarted)
                           JustStarted = 0;
                      else {
                           switch (*Buffer)
                             {
                             case 'L': Proc_Color_Cmd(Buffer); break;
                             case 'E': ResetArduino(); // Restart the Arduino
                                       break;
                             default: Serial.print((reinterpret_cast<const __FlashStringHelper *>(
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                   (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                   "#Unknown cmd:'"
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                   ); &__c[0];}))
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                   ))); Serial.print(Buffer); Serial.println((reinterpret_cast<const __FlashStringHelper *>(
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                                                                              (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                                                                              "'"
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                                                                              ); &__c[0];}))
# 417 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                                                                              )));// Debug
                             }
                           }
                      break;
           default: { // Add character to Buffer
                      uint8_t len = strlen(Buffer);
                      if (len < sizeof(Buffer)-1)
                           {
                           Buffer[len++] = c;
                           Buffer[len] = '\0';
                           }
                      else {
                           *Buffer = '\0';
                           Serial.println((reinterpret_cast<const __FlashStringHelper *>(
# 430 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                         (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 430 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                         "Buffer overflow"
# 430 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                         ); &__c[0];}))
# 430 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                         ))); // Debug
                           }
                      }
           }
        }
     }
}



  /*

   Problem:

   Bei der Lenz Zentrale LZV100 von Rolf wird keine Message beim

   loslassen des Tasters geschickt ;-(

   Das fuehrt dazu, dass die mit den Tasten verknuepften Ausgaenge nicht mehr aus gehen.

   Als Abhilfe wird die letzte Taste und der Zeitpunkt zu dem sie empfangen wurde

   gespeichert. Nach 400ms wird automatisch das Taste losgelassen Ereignis generiert.

   Wenn eine andere Taste empfangen wird wird die alte Taste ebenfalls "losgelassen".

  */
# 451 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
    uint8_t LastChannel;
    uint32_t LastTime = 0;



   //-----------------------------------------------------------------------------------------------
   void Update_InputCh_if_Addr_exists(uint16_t ReceivedAddr, uint8_t Direction, uint8_t OutputPower)
   //-----------------------------------------------------------------------------------------------
   {
     //Serial.print(F("Update_InputCh_if_Addr_exists ")); Serial.println(ReceivedAddr); // Debug
     uint16_t Channel = 0 /* Start number in the InpStructArray[]*/;
     for (const uint8_t *p = (const uint8_t*)Ext_Addr, *e = p + sizeof(Ext_Addr); p < e; )
         {
         uint16_t Raw_Addr = 
# 464 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                            (__extension__({ uint16_t __addr16 = (uint16_t)((uint16_t)(
# 464 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                            p
# 464 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                            )); uint16_t __result; __asm__ __volatile__ ( "lpm %A0, Z+" "\n\t" "lpm %B0, Z" "\n\t" : "=r" (__result), "=z" (__addr16) : "1" (__addr16) ); __result; }))
# 464 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                 ; p+=2;
         uint16_t Addr = Raw_Addr & 0x3FFF /* 14 Bits are used for the Address*/;
         uint16_t InTyp = Raw_Addr & ~0x3FFF /* 14 Bits are used for the Address*/;
         uint8_t InCnt = 
# 467 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                            (__extension__({ uint16_t __addr16 = (uint16_t)((uint16_t)(
# 467 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                            p
# 467 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                            )); uint8_t __result; __asm__ __volatile__ ( "lpm %0, Z" "\n\t" : "=r" (__result) : "z" (__addr16) ); __result; }))
# 467 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                 ; p++;
         //Serial.print("Addr:"); Serial.print(Addr); Serial.print(" InTyp:"); Serial.print(InTyp,HEX); Serial.print(" InCnt:"); Serial.println(InCnt); // Debug
         uint16_t ChkBut = InTyp;

         for (uint8_t In = 0; ; )
             {
             //Serial.print(In); Serial.print(" "); // Debug
             //Serial.print("In="); Serial.print(In); Serial.print(" ChkBut="); Serial.print(ChkBut,HEX); Serial.print(" Dir "); Serial.println(Direction); // Debug
             if (Addr == ReceivedAddr) // Addr is matching
                  {
                  if (ChkBut == (uint16_t)0) // OnOff switch
                       {
                       //char s[40]; sprintf(s, "OnOff: Addr %i Channel[%i]=%i Pow=%i", Addr, Channel, Direction, OutputPower); Serial.println(s);  // Debug
                       if (OutputPower > 0)
                            {
                            MobaLedLib.Set_Input(Channel, Direction > 0);
                            }
                       return ;
                       }
                  else { // Push Button

                          if ( (ChkBut == (uint16_t)(1<<14) && Direction == 0)
                              || (ChkBut == (uint16_t)(2<<14) && Direction > 0))




                             {
                             //char s[40]; sprintf(s, "%s Button Addr %i: Channel[%i]=%i", ChkBut==B_RED?"Red":"Green", Addr, Channel,OutputPower); Serial.println(s); // Debug
                             MobaLedLib.Set_Input(Channel, OutputPower);

                               if (OutputPower)
                                  {
                                  if (LastTime && LastChannel != Channel) MobaLedLib.Set_Input(LastChannel, 0); // Send release
                                  LastTime = millis();
                                  LastChannel = Channel;
                                  }

                             return ;
                             }
                       }
                  }
             // Addr dosn't match => Check the next possible address / InTyp for this entry
             //Serial.print("Don't match In="); Serial.println(In); // Debug
             Channel++;
             In++;
             if (In < InCnt)
                {

                   if (ChkBut == (uint16_t)0) Addr++;
                   else if (ChkBut == (uint16_t)(1<<14)) ChkBut = (uint16_t)(2<<14);
                   else if (ChkBut == (uint16_t)(2<<14)) {ChkBut = (uint16_t)(1<<14); Addr++; }



                }
             else break; // Exit the for loop
             }
         }
     //char s[30];sprintf(s, "Addr %i not found Dir:%i", ReceivedAddr, Direction); Serial.println(s);  // Debug
   }
# 737 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
   //----------------------------
   void Proc_Buffer(char *Buffer) // 13.05.20:  Added: Buffer
   //----------------------------
   {
     uint16_t Addr, Direction, OutputPower, State;
     //Serial.println(Buffer); // Debug
     switch (*Buffer)
       {
       case '@': if (sscanf(Buffer+1, "%i %x %x", &Addr, &Direction, &OutputPower) == 3)
                    {
                    Update_InputCh_if_Addr_exists(Addr+0, Direction, OutputPower); // 26.09.19:  Added: ADDR_OFFSET
                    return ;
                    }
                 break;
       case '$': if (sscanf(Buffer+1, "%i %x", &Addr, &State) == 2)
                    {
                    // Not implemented yet
                    return;
                    }
                 break;
       }
     Serial.println(" Parse Error");
   }
# 850 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
      //--------------------------------------------------------
      bool Get_Char_from_RS232_or_SPI(char &c, uint8_t &Buff_Nr)
      //--------------------------------------------------------
      {
        //PORTB &= ~3; // Disable D8 & D9   Debug Speed Test
        //DDRB  |=  3; // OUTPUT
        //PORTB |=  1;
# 881 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
 if (Serial.available() > 0)
  {
  Buff_Nr = 0;
  c = Serial.read();
  //PORTB |= 3;   // Debug Speed Test
  return 1;
  }
  //PORTB &= ~3;  // Debug Speed Test
  return 0;
 }

   //-----------------------
   void Proc_Received_Char()
   //-----------------------
   // Receive DCC Accessory Turnout messages:
   //  "@ 319 00 01\n":  Addr, Direction, OutputPower
   //
   // and DCC Signal Output messages:
   //  "$ 123 00\n":     Addr, State
   // For tests with the serial monitor use "Neue Zeile" instead of "Zeilenumbruch (CR)"
   {

       if (LastTime && millis()-LastTime > 400) // Use 1100 if no repeat is wanted
          {
          MobaLedLib.Set_Input(LastChannel, 0); // Send release
          LastTime = 0;
          // Serial.print(F("Release Button Channel[")); Serial.print(LastChannel); Serial.println("]=0"); // Debug
          }


     char c;
     uint8_t Buff_Nr;
     while (Get_Char_from_RS232_or_SPI(c, Buff_Nr))
       {
       //Serial.print(c); // Debug
       switch (c)
          {

             case '#': if (Buff_Nr==0) Receive_LED_Color_per_RS232(); // The first '#' is used to enable the serial color change mode  // 03.11.19:  // 13.05.20:  Added: if (Buff_Nr==0)
                       break;


            case '@':
            case '$': if (*Buffer[Buff_Nr]) Serial.println((reinterpret_cast<const __FlashStringHelper *>(
# 924 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                          (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 924 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                          " Unterm. Error"
# 924 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                          ); &__c[0];}))
# 924 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                          ))); // 13.05.20:  Added [Buff_Nr] to all Buffer usages in this and the following lines
                      *Buffer[Buff_Nr] = c; Buffer[Buff_Nr][1] = '\0';
                      break;
            default: // Other characters
                      uint8_t ExpLen;
                      switch(*Buffer[Buff_Nr])
                         {
                         case '@': ExpLen = 11; break;
                         case '$': ExpLen = 8; break;
                         default : ExpLen = 0;
                         //Serial.print(c); // Enable this line to show status messages from the DCC-Arduino
                         }
                      if (ExpLen)
                         {
                         uint8_t len = strlen(Buffer[Buff_Nr]);
                         if (len < ExpLen)
                              {
                              Buffer[Buff_Nr][len++] = c;
                              Buffer[Buff_Nr][len] = '\0';
                              }
                         else {
                              if (c != '\n')
                                   Serial.println((reinterpret_cast<const __FlashStringHelper *>(
# 946 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                 (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 946 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                 " Length Error"
# 946 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                                                 ); &__c[0];}))
# 946 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                 )));
                              else Proc_Buffer(Buffer[Buff_Nr]);
                              *Buffer[Buff_Nr] = '\0';
                              }
                         }

          }
       }
   }
# 994 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
# 995 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 2
  
# 995 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
 //----------------------
  void Debug_Print_Fuses() // 29.10.20:
  //----------------------
  // https://arduino.stackexchange.com/questions/24859/how-do-i-read-the-fuse-bits-from-within-my-sketch
  {
    
# 1000 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
   __asm__ __volatile__ ("cli" ::: "memory")
# 1000 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
        ;
    uint8_t highBits = 
# 1001 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                      (__extension__({ uint8_t __result; __asm__ __volatile__ ( "sts %1, %2\n\t" "lpm %0, Z\n\t" : "=r" (__result) : "i" (((uint16_t) &((*(volatile uint8_t *)((0x37) + 0x20))))), "r" ((uint8_t)(((1 << (0)) | (1 << (3))))), "z" ((uint16_t)((0x0003))) ); __result; }))
# 1001 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                                                                 ;
    
# 1002 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
   __asm__ __volatile__ ("sei" ::: "memory")
# 1002 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
        ;
    Serial.print((reinterpret_cast<const __FlashStringHelper *>(
# 1003 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 1003 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                "HFuse:"
# 1003 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                ); &__c[0];}))
# 1003 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                ))); Serial.println(highBits, 16);
  }






//-----------
void setup(){
//-----------

    /*********************/ CLEDController& controller0 = FastLED.addLeds<NEOPIXEL, 6>(leds+ 0, 20); controller0.clearLeds(256); /*End*/;
# 1029 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
  Serial.begin(115200 /* Should be equal to the DCC_Rail_Decoder_Transmitter.ino program*/); // Communication with the DCC-Arduino must be fast



    Serial.println((reinterpret_cast<const __FlashStringHelper *>(
# 1033 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                  (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 1033 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                  "LEDs_AutoProg Ver 1: MobaLedLib_1.0.1 19.01.20 16:50"
# 1033 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                  ); &__c[0];}))
# 1033 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                  )));

  // Debug_Print_Fuses();


    Serial.print((reinterpret_cast<const __FlashStringHelper *>(
# 1038 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                (__extension__({static const char __c[] __attribute__((__progmem__)) = (
# 1038 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                "#Color Test LED cnt:"
# 1038 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino" 3
                ); &__c[0];}))
# 1038 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
                ))); Serial.println(242 /* Number of LEDs (Maximal 256 RGB LEDs could be used)*/); // Without this message the program fails with the message
# 1048 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
//  #define GCC_VERSION (__GNUC__ * 10000L + __GNUC_MINOR__ * 100L + __GNUC_PATCHLEVEL__)
//  Serial.print(F("GCC_VERSION:")); Serial.println(GCC_VERSION);



    pinMode(A1 /* Pin A1 is used to stop the DCC, Selectrix, ... Arduino from sending RS232 characters*/, 0x1);
    digitalWrite(A1 /* Pin A1 is used to stop the DCC, Selectrix, ... Arduino from sending RS232 characters*/, 0);
# 1079 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
  Set_Start_Values(MobaLedLib); // The start values are defined in the "MobaLedLib.h" file if entered by the user
# 1093 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
  //#else                                                                                                     // 04.11.20:  Disabled



  //#endif
# 1119 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
  if (millis() < 1500) delay(1500 - millis()); // Wait to prevent flickering if the Arduino is detected from the excel program  // 05.05.20:
# 1262 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
}
# 1317 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
//-----------------------
void Set_Mainboard_LEDs()
//-----------------------
{
# 1493 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
}
# 1621 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
//-----------
void loop(){
//-----------





  MLLMainLoop();





}
# 1649 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
//-----------------
void MLLMainLoop(){
//-----------------
# 1662 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
    LED_HeartBeat.Update();



  MobaLedLib.Update(); // Update the LEDs in the configuration






    Proc_Received_Char(); // Process characters received from the RS232 (DCC, Selectrix, ... Arduino)
# 1691 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
    if (Send_Disable_Pin_Active) digitalWrite(A1 /* Pin A1 is used to stop the DCC, Selectrix, ... Arduino from sending RS232 characters*/, 1); // Stop the sending of the DCC-Arduino because the RS232 interrupts are not processed during the FastLED.show() command  // 13.05.20:  Added: if (Send_Disable_Pin_Active)
# 1703 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
  Set_Mainboard_LEDs(); // Turn on/off the LEDs on the mainboard if configured

  FastLED.show(); // Show the LEDs (send the leds[] array to the LED stripe)


    if (Send_Disable_Pin_Active) digitalWrite(A1 /* Pin A1 is used to stop the DCC, Selectrix, ... Arduino from sending RS232 characters*/, 0); // Allow the sending of the DCC commands again  // 13.05.20:  Added: if (Send_Disable_Pin_Active)
# 1718 "d:\\data\\Development\\python\\ARDUINO\\MobaLedLib\\Ver_2.1.2\\LEDs_AutoProg.ino"
}
