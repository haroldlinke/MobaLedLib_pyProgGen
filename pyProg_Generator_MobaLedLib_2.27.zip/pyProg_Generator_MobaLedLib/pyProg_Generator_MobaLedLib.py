# -*- coding: utf-8 -*-
#
#         MobaLedCheckColors: Color checker for WS2812 and WS2811 based MobaLedLib
#
# * Version: 1.21
# * Author: Harold Linke
# * Date: January 1st, 2020
# * Copyright: Harold Linke 2020
# *
# *
# * MobaLedCheckColors on Github: https://github.com/haroldlinke/MobaLedCheckColors
# *
# *
# * History of Change
# * V1.00 23.11.2019 - Harold Linke - first release
# * V1.09 29.11.2019
# * V1.10 03.12.2019 - Hardi
# *                  - Brightness could be shown in pecent if the constant PERCENT_BRIGHTNESS is set to 1
# *                  - Write a finish file at the end of the program. This is needed by the calling excel program.
# *                    Harold: Is this file also written in case of a crash ?
# *                  - Some more detailed error messages
# *       04.12.2019 - Added COM Ports 7..40 because on some systems such high com ports are used (Hardi: COM12)
# *                    Hint: For test purposes the COM Port could be changed in the device manager: "devmgmt.msc" in windows
# *                  - Send "#End" when the program is closed to restart the arduino. Prior if was still in the ColorChecker mode (LED was flashing fast)
# *                  - Moved the sending og the "#BEGIN" command down because the Arduino is restarted if the serial connection is opened
# *                    => The "#BEGIN" command was not received
# *                    With this change the first press to a color button is raccepted (Prior a second press was needed)
# *                  - The serial monitor could be started in the json file with "startpage": 2,
# *                  - Increased the size of the serial monitor window
# *                  - Added "End" button to the serial monitor
# * V1.13 13.12.2019 - Harold
# *                  - corrector error in reset color palette procedure, color palette was not copied correctly
# *                  - corrected old_color behavior, stores now the current color when a new color is selected from the palette
# *                  - color correction moved to configuration page to reduce size of window for smaller screens
# * V1.14 15.12.2019 - Harold
# *                  - program was nearly unreactiv, when ARDUINO connection was disconnected, corrected
# * V1.15 16.12.2019 - Harold
# *                  - Baudrate can be configured
# *                  - Collorcorrection moved to config page
# *                  - HSV is using English terms
# * V1.16 26-12-2019 - Harold
# *                  - complete restructuring of all parts
# *                  - check for response of ARDUINO - first response must include "MobaLedLib"
# *                  - use tabs to switch between pages
# *                  - menu for accessing functions
# *                  - right-click menu for palette colors
# *                  - reset to standard color isnow possible for each palette entry seperately
# *                  - Palette can now be saved to file and read back
# *                  - Baudrate fixed to 115000
# *                  - reduced size to comply with smaller screens
# *                  - colorwheel changed to conform with Philips Hue colorwheel
# *                  - tooltips added
# *                  - LED(s) now blinks in White when selected
# *                  - All colors for the LEDs are saved in an LED list. The list is send to the ARDUINO when the color is changed.
# * V1.17 28-12-2019 - BLINKFRQ changed to 1 Hz
# *                  - deleted Baudrate selection - fixed to 115000
# *                  - LEDListPage now shows the colors of the LEDs
# *                   
# * V1.18 28-12-2019 - Checks now for "#Color Test LED" during connection - if not received after 5 seocnds connection is interrupted (may be wrong ARDUINO answering
# *                  - receive max LED count from ARDUINO - only in ConfigPage - not dynamically updated in ColorCheckPage yet
# *                  - corrected calculation of BLINKFRQ
# *                  - Colorcorrection vaules are now taken into account immediatly without restart
# *                  - Colorsquare removed
# *                  - Shortcut key hints moved to tooltips
# *                  - new Status line at the bottom shows ARDUINO Status
# * V1.19 29-12-2019 - Neue Datei-Menu  Option „Beenden und Änderungen verwerfen.
# *                  - Colorcheckpage als Startseite wenn nichts angegeben ist
# *                  - Blinkende LED anpassen, wenn Anzahl geändert wird
# *                  - Bei Click auf die Aktuelle Farbe sollte die LED die aktuelle Farbe auch anzeigen.
# *                  - Vertausche Cursortasten für Startadresse und Anzahl 
# *                  - add button for blinking off
# *                  - CTRL-Right Mousebutton for save color in palette
# * V1.20 30-12-2019 - replace old_color with undo feature
# *                  - Abfrage beim Benenden ohne Speichern geändert - Soll die Palette (ColTab) gesichert werden?
# *                  - all LEDs are switched off at start-up
# *                  - error when ARDUINO connection to possible during startup with shortcuts and text entry not working corrected
# *                  - help page updated
# *                  - ERROR: LED selected after start of program automatically gets the current color - corrected
# * V1.21 01-01-2020 - ColTab Parameter von MobaLedLib wurden nicht richtig gelesen
# *                  - Fehlerkorrektur in V1.19 "LED selected after start of program automatically gets the current color - corrected" führte zu dem Fehler, dass die Anfangshelligkeit auf 0 gesetzt war - korrigiert
# * V1.22 02-01-2020 - Switch to HSV square did not work correctly
# *                  - Hue can now turnaround (after 360 it switches to 0)
# * V1.23 02-01-2020 - reads ledcnt_max from ARDUINO and checks if led-number + led count < ledcnt_max
# * V1.24 03-01-2020 - question to save palette only when palette ws changed
# *                  - window position will be saved correctly after cancel without save
# *                  - Buttob blinking off changed to on and off switch
# * V1.25 03-01-2020 - test changed from "MoDaLedLib" to „LEDs_AutoProg"
# *                  - "b'" removed from read string from serial interface
# * V1.26 04-01-2020 - added Soundtest
# * V1.27 19-01-2020 - error in max LED calculation corrected
# *  
# * https://github.com/Hardi-St/MobaLedLib
# *
# * MobaLedCheckColors is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * MobaLedCheckColors is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program.  If not, see <http://www.gnu.org/licenses/>.
# *
# * MobaLedCheckColors is based on tkColorPicker by Juliette Monsel
# * https://sourceforge.net/projects/tkcolorpicker/
# *
# * tkcolorpicker - Alternative to colorchooser for Tkinter.
# * Copyright 2017 Juliette Monsel <j_4321@protonmail.com>
# *
# * tkcolorpicker is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * tkcolorpicker is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program.  If not, see <http://www.gnu.org/licenses/>.
# *
# * The code for changing pages was derived from: http://stackoverflow.com/questions/7546050/switch-between-two-frames-in-tkinter
# * License: http://creativecommons.org/licenses/by-sa/3.0/
# ***************************************************************************

import tkinter as tk
from tkinter import ttk,messagebox,filedialog, scrolledtext
from mlpyproggen.configfile import ConfigFile
from mlpyproggen.dictFile import readDictFromFile, saveDicttoFile
from mlpyproggen.ConfigurationPage import ConfigurationPage
from mlpyproggen.SerialMonitorPage import SerialMonitorPage
from mlpyproggen.ColorCheckPage import ColorCheckPage
from mlpyproggen.EffectTestPage import EffectTestPage
from mlpyproggen.EffectMacroPage import EffectMacroPage
from mlpyproggen.DCC_KeyboardPage import DCCKeyboardPage
from mlpyproggen.ServoTestPage import ServoTestPage
from mlpyproggen.Z21MonitorPage import Z21MonitorPage
from mlpyproggen.StartPage import StartPage
from mlpyproggen.LEDListPage import LEDListPage
from mlpyproggen.SoundCheckPage import SoundCheckPage
from mlpyproggen.tooltip import Tooltip
from mlpyproggen.DefaultConstants import COLORCOR_MAX, CONFIG2PARAMKEYS, DEFAULT_CONFIG, DEFAULT_PALETTE, DEFAULT_PARAM, LARGE_FONT, SMALL_FONT, VERY_LARGE_FONT, VERSION, \
PARAM_FILENAME, CONFIG_FILENAME, DISCONNECT_FILENAME, CLOSE_FILENAME, HELPPAGE_FILENAME, FINISH_FILE, PERCENT_BRIGHTNESS, TOOLTIPLIST, SerialIF_teststring1, SerialIF_teststring2, MACRODEF_FILENAME, MACROPARAMDEF_FILENAME
from mlpyproggen.LedEffectTable import ledeffecttable_class
from scrolledFrame.VerticalScrolledFrame import VerticalScrolledFrame
from tkcolorpicker.spinbox import Spinbox
from tkcolorpicker.limitvar import LimitVar

from locale import getdefaultlocale
import os
import serial
import sys
import threading
import queue
import time
import logging
import webbrowser
import argparse
from datetime import datetime


# --- Translation - not used
EN = {}
FR = {}
DE = {"Red": "Rot", "Green": "Grün", "Blue": "Blau",
      "Hue": "Farbton", "Saturation": "Sättigung", "Value": "Helligkeit",
      "Cancel": "Beenden", "Color Chooser": "Farbwähler",
      "Alpha": "Alpha", "Configuration": "Einstellungen",
      "ROOM_COL0": "SetColTab Parameter: ROOM_COL0\nRaumfarbe 0 \nRechte Maustaste für Funktionen",
      "ROOM_COL1": "SetColTab Parameter: ROOM_COL1\nRaumfarbe 1 \nRechte Maustaste für Funktionen",
      "ROOM_COL2": "SetColTab Parameter: ROOM_COL2\nRaumfarbe 2 \nRechte Maustaste für Funktionen",
      "ROOM_COL3": "SetColTab Parameter: ROOM_COL3\nRaumfarbe 3 \nRechte Maustaste für Funktionen",
      "ROOM_COL4": "SetColTab Parameter: ROOM_COL4\nRaumfarbe 4 \nRechte Maustaste für Funktionen",
      "ROOM_COL5": "SetColTab Parameter: ROOM_COL5\nRaumfarbe 5 \nRechte Maustaste für Funktionen",
      "GAS_LIGHT D" : "SetColTab Parameter: GAS_LIGHT D\nSimuliert dunkles Gaslicht \nRechte Maustaste für Funktionen",
      "GAS LIGHT"   : "SetColTab Parameter: GAS LIGHT\nSimuliert Gaslicht \nRechte Maustaste für Funktionen",
      "NEON_LIGHT D": "SetColTab Parameter: NEON_LIGHT D\nSimuliert dunkles Neonlicht \nRechte Maustaste für Funktionen",
      "NEON_LIGHT M": "SetColTab Parameter: NEON_LIGHT M\nSimuliert mittel helles Neonlicht \nRechte Maustaste für Funktionen",
      "NEON_LIGHT"  : "SetColTab Parameter: NEON_LIGHT\nSimuliert Neonlicht \nRechte Maustaste für Funktionen",
      "ROOM_TV0 A"  : "SetColTab Parameter: ROOM_TV0 A\nRaumfarbe A - wenn TV0 aus ist \nRechte Maustaste für Funktionen",
      "ROOM_TV0 B"  : "SetColTab Parameter: ROOM_TV0 B\nRaumfarbe B - wenn TV0 aus ist \nRechte Maustaste für Funktionen",
      "ROOM_TV1 A"  : "SetColTab Parameter: ROOM_TV1 A\nRaumfarbe A - wenn TV1 aus ist \nRechte Maustaste für Funktionen",
      "ROOM_TV1 B"  : "SetColTab Parameter: ROOM_TV1 B\nRaumfarbe B - wenn TV1 aus ist \nRechte Maustaste für Funktionen",
      "SINGLE_LED"  : "SetColTab Parameter: SINGLE_LED \nEinzel LEDs \nRechte Maustaste für Funktionen",
      "SINGLE_LED D": "SetColTab Parameter: SINGLE_LED D\nEinzel LEDs dunkel \nRechte Maustaste für Funktionen"            
      }

try:
    TR = DE
    #if getdefaultlocale()[0][:2] == 'fr':
    #    TR = FR
    #else:
    #    if getdefaultlocale()[0][:2] == 'en':
    #        TR = EN
except ValueError:
    TR = DE

def _(text):
    """Translate text."""
    return TR.get(text, text)

# ------------------------------

# ********************************************************************************
# *
# * definition of different tab dictionaries defining the relationship between tabname, pagename, page classes and index
# * in fact only one table would be needed, and all others could begenerate automatically, but for clarity it is done here explicitely

tabClassList = ( StartPage, EffectTestPage, EffectMacroPage, ColorCheckPage, SoundCheckPage, DCCKeyboardPage, ServoTestPage, Z21MonitorPage, SerialMonitorPage, ConfigurationPage)


# for compatibility with the "old" startpagenumber in the config file
# if startpagenumber is in this list the corresponding start page is opened, otherwise "ColorCheckPage"
startpageNumber2Name = { 
    "0": "ConfigurationPage",
    "1": "ColorCheckPage",
    "2": "SerialMonitorPage"
}

defaultStartPage = "ColorCheckPage"

ThreadEvent = None

# ----------------------------------------------------------------
# Class LEDColorTest
# ----------------------------------------------------------------

class LEDColorTest(tk.Tk):
    
    # ----------------------------------------------------------------
    # LEDColorTest __init__
    # ----------------------------------------------------------------
    def __init__(self, *args, **kwargs):

        self.arduino = None
        self.queue = queue.Queue(maxsize=100)
        self.readConfigData()
        self.ledtable = {"000": "#FFFFFF"}
        self.ledgrouptable = {
                                "Gruppenname": {
                                    "Name": "Gruppenname",
                                    "params": {
                                        "Group_Name": "Gruppenname",
                                        "Group_Colour": "#FFFFFF",
                                        "Group_Distributor": "",
                                        "Group_Connector": "",
                                        "Group_Comment": ""
                                    }
                                },
                                "Gruppenname2": {
                                    "Name": "Gruppenname",
                                    "params": {
                                        "Group_Name": "Gruppenname2",
                                        "Group_Colour": "#FFFF00",
                                        "Group_Distributor": "",
                                        "Group_Connector": "",
                                        "Group_Comment": ""
                                    }
                                }                                
                            }        
        self.ledeffecttable = ledeffecttable_class(self.ledgrouptable, self)
        self.ledeffecttable.init_ledeffecttable()

        self.macroparams_value = {}
        self.ledeffect_label_list = {}
        self.macroparams_var = {"dummy": {}}
        self.persistent_param_dict = {}
        self.macroparam_frame_dict = {}
        self.bind_keys_dict = {}

        # Structure:
        # self.serial_port_dict={"COM3": {
        #                         "dcc_address_range": (0,1024),   # the port select in the configuration
        #                         "ARDUINO" : None}
        #                       }
        
        self.serial_port_dict={}
        
        self.currentTabClass = ""
        self.maxLEDcnt = self.getConfigData("MaxLEDcnt")
        self.paramDataChanged = False
        self.palette = {}
        self.connection_startup = False

        tk.Tk.__init__(self, *args, **kwargs)
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        if self.getConfigData("pos_x") < screen_width and self.getConfigData("pos_y") < screen_height:

            self.geometry('+%d+%d' % (self.getConfigData("pos_x"), self.getConfigData("pos_y")))
        else:
            self.geometry("+100+100")

        tk.Tk.wm_title(self, "MobaLedLib " + VERSION)

        self.title("MobaLedLib " + VERSION)
        self.transient(self.master)
        #self.resizable(False, False)
        self.resizable(True,True)
        #self.rowconfigure(1, weight=1)

        self.color = ""
        style = ttk.Style(self)
        style.map("palette.TFrame", relief=[('focus', 'sunken')],
                  bordercolor=[('focus', "#4D4D4D")])
        self.configure(background=style.lookup("TFrame", "background"))
         
        menu = tk.Menu(self)
        self.config(menu=menu)
        filemenu = tk.Menu(menu)
        menu.add_cascade(label="Datei", menu=filemenu)
        filemenu.add_command(label="Farbpalette von Datei lesen", command=self.OpenFile)
        filemenu.add_command(label="Farbpalette speichern als ...", command=self.SaveFileas)
        filemenu.add_separator()
        filemenu.add_command(label="LED Tabelle von Datei lesen", command=self.OpenFileLEDTab)
        filemenu.add_command(label="LED Tabelle speichern als", command=self.SaveFileLEDTab)
        filemenu.add_separator()
        filemenu.add_command(label="Beenden und Daten speichern", command=self.ExitProg_with_save)
        filemenu.add_command(label="Beenden ohne Daten zu speichern", command=self.ExitProg)

        colormenu = tk.Menu(menu)
        menu.add_cascade(label="Farbpalette", menu=colormenu)
        colormenu.add_command(label="letzte Änderung Rückgängig machen [CTRL-Z]", command=self.MenuUndo)
               
        colormenu.add_command(label="von Datei lesen", command=self.OpenFile)
        colormenu.add_command(label="speichern als ...", command=self.SaveFileas)
        colormenu.add_separator()
        colormenu.add_command(label="auf Standard zurücksetzen", command=self.ResetColorPalette)

        arduinomenu = tk.Menu(menu)
        menu.add_cascade(label="ARDUINO", menu=arduinomenu)
        arduinomenu.add_command(label="Verbinden", command=self.ConnectArduino)
        arduinomenu.add_command(label="Trennen", command=self.DisconnectArduino)
        arduinomenu.add_command(label="Alle LED aus", command=self.SwitchoffallLEDs)
        
        helpmenu = tk.Menu(menu)
        menu.add_cascade(label="Hilfe", menu=helpmenu)
        helpmenu.add_command(label="Hilfe öffnen", command=self.OpenHelp)
        helpmenu.add_command(label="Über...", command=self.About)

        # --- define container for tabs
        
        #self.scrolledframe = VerticalScrolledFrame(self)
        #self.scrolledframe.pack(side="top", fill="both", expand = True)
        
        #self.container = ttk.Notebook(self.scrolledframe.interior)
 
        self.container = ttk.Notebook(self)
        self.grid_rowconfigure(0,weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.container.grid(row=0,column=0,sticky="nesw")
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self.tabdict = dict()
        
        for tabClass in tabClassList:
            frame = tabClass(self.container,self)
            tabClassName = frame.tabClassName
            self.tabdict[tabClassName] = frame
            self.container.add(frame, text=frame.tabname)
        
        self.continueCheckDisconnectFile = True
        self.onCheckDisconnectFile() 
        
        self.container.bind("<<NotebookTabChanged>>",self.TabChanged)
        
        startpagename = self.getStartPageClassName()
        
        #if self.getConfigData("startpage") == 1:
        #    self.showFramebyName("ColorCheckPage")
        #else:
        #    if self.getConfigData("startpage") == 2:                                      # 04.12.19:  
        #        self.showFramebyName("SerialMonitorPage")
        #    else:
        #        self.showFramebyName("ConfigurationPage")
        
        self.showFramebyName(startpagename)
        
        self.statusmessage = tk.Label(self, text='Status:', fg="black",bd=1, relief="sunken", anchor="w")
        self.statusmessage.grid(row=2,column=0,sticky="ew")
        #self.statusmessage.pack(side="bottom", fill="x")
        self.ToolTip(self.statusmessage, text="Zeigt den Status der Verbindung zum ARDUINO an: \nVerbunden - eine Verbindung zum ARDUINO steht\nNicht verbunden - keine Verbindung zum ARDUINO")
        
        self.focus_set()
        self.wait_visibility()
                
        self.lift()
        self.grab_set()        

           

    def SaveFileas(self):
        filepath = filedialog.asksaveasfilename(filetypes=[("JSON files","*.json")],defaultextension=".json")
        if filepath:
            frame = self.tabdict["ColorCheckPage"]
            frame.savePalettetoFile(filepath) 

    def SaveFile(self):
        filepath = PARAM_FILENAME
        if filepath:
            frame = self.tabdict["ColorCheckPage"]
            frame.savePalettetoFile(filepath) 

    def OpenFile(self):
        filepath = filedialog.askopenfilename(filetypes=[("JSON files","*.json")],defaultextension=".json")
        if filepath:
            frame = self.tabdict["ColorCheckPage"]
            frame.readPalettefromFile(filepath)         

    def SaveFileLEDTab(self):
        filepath = filedialog.asksaveasfilename(filetypes=[("JSON files","*.json")],defaultextension=".json")
        if filepath:
            self.saveLEDTabtoFile(filepath)

    def OpenFileLEDTab(self):
        filepath = filedialog.askopenfilename(filetypes=[("JSON files","*.json")],defaultextension=".json")
        if filepath:
            self.readLEDTabfromFile(filepath)     

    def About(self):
        tk.messagebox("MobaCheckColor by Harold Linke")

    def OpenHelp(self):
        self.call_helppage()

    def ResetColorPalette(self):
        frame = self.tabdict["ColorCheckPage"]
        frame.palette_reset_colors()

    def MenuUndo(self,_event=None):
        for key in self.tabdict:
            self.tabdict[key].MenuUndo() 
    
    def MenuRedo(self,_event=None):
        for key in self.tabdict:
            self.tabdict[key].MenuRedo()

    def ConnectArduino(self):
        self.connect()

    def DisconnectArduino(self):
        self.disconnect()

    def SwitchoffallLEDs(self):
        # switch off all LED
        message = "#L00 00 00 00 FF\n"
        self.send_to_ARDUINO(message)        
        
    def ExitProg(self):
        self.cancel()
        
    def ExitProg_with_save(self):
        self.cancel_with_save()    

    def saveLEDTabtoFile(self, filepath):
               
        temp_dict = {"ledeffecttable":self.ledeffecttable.get_table(),
                     "ledgrouptable" :self.ledgrouptable}
        
        saveDicttoFile(filepath, temp_dict)

    def readLEDTabfromFile(self, filepath):
        temp_dict = readDictFromFile(filepath)
        if temp_dict:
            self.ledeffecttable.set_table(temp_dict.get("ledeffecttable",{}))
            self.ledgrouptable  = temp_dict.get("ledgrouptable",{})
        self.current_tab.tabselected()
        
    def save_persistent_params(self):
        for macro in self.persistent_param_dict:
            persistent_param_list = self.persistent_param_dict[macro]
            for paramkey in persistent_param_list:
                self.setConfigData(paramkey, self.get_macroparam_val(macro, paramkey))
            
    # ----------------------------------------------------------------
    #  cancel_with_save
    # ----------------------------------------------------------------
    def cancel_step2_with_save(self):
        logging.info("Cancel_with_save")
        self.setConfigData("pos_x", self.winfo_x())
        self.setConfigData("pos_y", self.winfo_y())
        self.save_persistent_params()
        self.SaveConfigData()
        self.SaveParamData()        
        self.close_notification()
        
    def cancel_step2_without_save(self):
        
        self.close_notification()           

    # ----------------------------------------------------------------
    #  cancel_with_save
    # ----------------------------------------------------------------
    def cancel_with_save(self):
        self.set_connectstatusmessage("Closing program...",fg="red")
        i=0
        for key in self.tabdict:
            self.tabdict[key].cancel()
            self.container.tab(i, state="disabled")
            i+=1
        self.after(200, self.cancel_step2_with_save) # a trick to show the close message before closing   

        #open(FINISH_FILE, 'a').close()                                       # 03.12.19:
        #self.disconnect()
        #self.continueCheckDisconnectFile = False
        #self.destroy()

    # ----------------------------------------------------------------
    #  cancel_without_save
    # ----------------------------------------------------------------
    def cancel_without_save(self):
        logging.info("Cancel_without_save")
        self.set_connectstatusmessage("Closing program...",fg="red")
        i=0
        for key in self.tabdict:
            #self.tabdict[key].cancel()
            self.container.tab(i, state="disabled")
            i+=1        
        self.after(200, self.cancel_step2_without_save) # a trick to show the close message before closing

    # ----------------------------------------------------------------
    #  cancel
    # ----------------------------------------------------------------
    def cancel(self):
        if self.paramDataChanged:
            answer = tk.messagebox.askyesnocancel ('Das Programm wird beendet','Soll die Palette (ColTab) gesichert werden?',default='no')
            if answer == None:
                return # no cancelation
            
            if answer:
                self.cancel_with_save() 
            else:
                self.cancel_without_save()
        else:
            self.cancel_without_save()


    def close_notification(self):
        
        for key in self.tabdict:
            self.tabdict[key].cancel()
        self.setConfigData("pos_x", self.winfo_x())
        self.setConfigData("pos_y", self.winfo_y())
        if self.ParamData.data == {}: # ParamData is not used, interface is config data. In this case do not save config data - compatibility modus
            self.SaveConfigData()
        open(FINISH_FILE, 'a').close()                                       # 03.12.19:
        self.disconnect()
        self.continueCheckDisconnectFile = False
        self.destroy()        
        
        
    # ----------------------------------------------------------------
    # show_frame byName
    # ----------------------------------------------------------------
    def showFramebyName(self, pageName):
        frame = self.tabdict.get(pageName,None)
        if frame == None:
            pageName = "ColorCheckPage"
            frame = self.tabdict.get(pageName,None)
        if pageName == "ColorCheckPage":
            frame._update_cor_rgb()
        self.container.select(self.tabdict[pageName])

    # ----------------------------------------------------------------
    # Event TabChanged
    # ----------------------------------------------------------------        
    def TabChanged(self,_event=None):
        oldtab_name = self.currentTabClass
        if oldtab_name != "":
            oldtab = self.nametowidget(oldtab_name)
            oldtab.tabunselected()
        newtab_name = self.container.select()
        if newtab_name != "":
            newtab = self.nametowidget(newtab_name)
            newtab.tabselected()
            self.currentTabClass = newtab_name
            self.current_tab = newtab

    # ----------------------------------------------------------------
    # setParamDataChanged
    # ----------------------------------------------------------------        
    def setParamDataChanged(self):
        self.paramDataChanged=True
        
    # ----------------------------------------------------------------
    # LEDColorTest connect ARDUINO
    # ----------------------------------------------------------------
    def connect(self):

        logging.info("connect")
        port = self.getConfigData("serportname")
        self.ARDUINO_message = ""
        self.set_connectstatusmessage("Nicht Verbunden",fg="black")
        timeout_error = False
        read_error =False
        text_string = "ERROR"
        
        if self.arduino and self.arduino.isOpen():
            self.disconnect()

        if port!="NO DEVICE":
            try:
                self.arduino = serial.Serial(port,baudrate=self.getConfigData("baudrate"),timeout=2,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS)
                logging.info("connected to: " + self.arduino.portstr)
            except:                 # 03.12.19: more detailed error message
                messagebox.showerror("Error connecting to the serial port " + self.getConfigData("serportname"),
                                     "Serial Interface to ARDUINO could not be opened!\n"
                                     "\n"
                                     "Check if an other program is using the serial port\n"
                                     "This could be the Ardiono IDE/serial monitor or an\n"
                                     "other instance of this program.")
                
                self.arduino = None
                return False
            
            timeout_error = True
            try:
                text=""
                text = self.arduino.readline()
                timeout_error = False
                # check if feedback is from MobaLedLib
                text_string = text.decode('utf-8')
                
                if text_string.find(SerialIF_teststring1) == -1:
                    read_error = True
                else:
                    self.queue.put(text_string)
                    logging.info("Connect message: %s", text_string)
            except (IOError,UnicodeDecodeError):
                read_error = True
                
            if read_error:         
                messagebox.showerror("Error when reading Arduino answer",
                                     "Wrong answer from ARDUINO:\n"                                  # 02.01.20:  Ausgabe der empfangenen Message. Das Hilft evtl. bei der Fehlersuche
                                     " '" + text_string + "'\n"                                      # 02.01.20:  ToDo: Woher kommt das 'b am Anfang der Meldung? das "\n\r" muss auch nicht angezeigt werden
                                     "\n"
                                     "Check if the correct program is loaded to the arduino.\n"
                                     "It must be compiled with the compiler switch:\n"               # 02.01.20:  Old: "becompiled"
                                     "  #define RECEIVE_LED_COLOR_PER_RS232")
                
                self.arduino = None
                return False                

            if timeout_error:         # 03.12.19: more detailed error message
                messagebox.showerror("Timeout waiting for the Arduino answer",
                                     "ARDUINO is not answering.\n"
                                     "\n"
                                     "Check if the correct program is loaded to the arduino.\n"
                                     "It must becompiled with the compiler switch:\n"
                                     "  #define RECEIVE_LED_COLOR_PER_RS232")
                
                self.arduino = None
                return False
            else:
                self.connection_startup = True
                self.connection_startup_time = 100 # 5 seconds time to send the correct messages
                self.connection_startup_answer = False
                for key in self.tabdict:
                    self.tabdict[key].connect()
                    
                    
                port_dcc_data = self.serial_port_dict.get(port,{})
                if port_dcc_data != {}:
                    port_dcc_data["ARDUINO"] = self.arduino
                else:
                    self.serial_port_dict[port] ={"dcc_address_range": (1,9999), 
                                                  "ARDUINO" : self.arduino}
                    logging.info(" %s added to Z21 list",port)
                            

                #if self.getConfigData("startpage") == 1: # Just send the begin if the LED page shown at the start 
                #    message = "#BEGIN\n"                                     # 04.12.19: New location 
                #    self.send_to_ARDUINO(message)        # #BEGIN will be send everytime when the COLORTEST Tab is selected automatically
                
                self.set_connectstatusmessage("Verbunden - Warten auf korrekte Antwort von ARDUINO ...",fg="orange")
                return True
            return False
        else:
            return False

    # ----------------------------------------------------------------
    # LEDColorTest connect ARDUINO
    # ----------------------------------------------------------------
    def connect_Z21(self,port,dcc_adress_range):

        logging.info("connect ", port)
        if port == self.getConfigData("serportname"):
            self.disconnect()
        
        arduino = None
        port_dcc_data = self.serial_port_dict.get(port,{})
        if port_dcc_data != {}:
            arduino = port_dcc_data.get("ARDUINO",None)        
            if arduino and arduino.isOpen():
                self.disconnect_Z21(port)
                arduino = None

        timeout_error = False
        read_error =False
        text_string = "ERROR"

        if port!="NO DEVICE" and not arduino:
            try:
                arduino = serial.Serial(port,baudrate=self.getConfigData("baudrate"),timeout=2,parity=serial.PARITY_NONE,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS)
                logging.info("connected to: " + port)
            except:                 # 03.12.19: more detailed error message
                messagebox.showerror("Error connecting to the serial port " + port,
                                     "Serial Interface to ARDUINO could not be opened!\n"
                                     "\n"
                                     "Check if an other program is using the serial port\n"
                                     "This could be the Ardiono IDE/serial monitor or an\n"
                                     "other instance of this program.")
                
                arduino = None
                return False
            
            timeout_error = True
            try:
                text=""
                text = arduino.readline()
                timeout_error = False
                # check if feedback is from MobaLedLib
                text_string = text.decode('utf-8')
                
                if text_string.find(SerialIF_teststring1) == -1:
                    read_error = True
                else:
                    self.queue.put(text_string)
                    logging.info("Connect message: %s", text_string)
            except (IOError,UnicodeDecodeError):
                read_error = True
                
            if read_error:         
                messagebox.showerror("Error when reading Arduino answer",
                                     "Wrong answer from ARDUINO:\n"                                  # 02.01.20:  Ausgabe der empfangenen Message. Das Hilft evtl. bei der Fehlersuche
                                     " '" + text_string + "'\n"                                      # 02.01.20:  ToDo: Woher kommt das 'b am Anfang der Meldung? das "\n\r" muss auch nicht angezeigt werden
                                     "\n"
                                     "Check if the correct program is loaded to the arduino.\n"
                                     "It must be compiled with the compiler switch:\n"               # 02.01.20:  Old: "becompiled"
                                     "  #define RECEIVE_LED_COLOR_PER_RS232")
                
                arduino = None
                return False                

            if timeout_error:         # 03.12.19: more detailed error message
                messagebox.showerror("Timeout waiting for the Arduino answer",
                                     "ARDUINO is not answering.\n"
                                     "\n"
                                     "Check if the correct program is loaded to the arduino.\n"
                                     "It must becompiled with the compiler switch:\n"
                                     "  #define RECEIVE_LED_COLOR_PER_RS232")
                
                arduino = None
                return False
            else:
                
                port_dcc_data = self.serial_port_dict.get(port,{})
                if port_dcc_data != {}:
                    port_dcc_data["ARDUINO"] = arduino
                else:
                    self.serial_port_dict[port] ={"dcc_address_range": dcc_adress_range, 
                                                  "ARDUINO" : arduino}
                    logging.info("%s added to list",port)
                    if port == self.getConfigData("serportname"):
                        self.arduino = arduino                
                
                return True
            return False
        else:
            return False

    # ----------------------------------------------------------------
    # LEDColorTest disconnect ARDUINO
    # ----------------------------------------------------------------
    def disconnect_Z21(self,port):
        logging.info("disconnect Z21 serial port: %s", port)
        arduino = None
        port_dcc_data = self.serial_port_dict.get(port,{})
        if port_dcc_data != {}:
            arduino = port_dcc_data.get("ARDUINO",None)                
        
            if arduino:
                arduino.close()
                arduino = None
                del self.serial_port_dict[port]
                logging.info("%s deleted from list",port)
        self.stop_process_serial_all()

    # ----------------------------------------------------------------
    # LEDColorTest disconnect ARDUINO
    # ----------------------------------------------------------------
    def disconnect(self):
        self.led_off()    
        logging.info("disconnect")
        if self.arduino:
            for key in self.tabdict:
                self.tabdict[key].disconnect()
            
            message = "#END\n"
            self.send_to_ARDUINO(message)

            self.arduino.close()
            self.arduino = None
            self.set_connectstatusmessage("Nicht Verbunden",fg="black")
            
    def connect_if_not_connected(self):
        if self.arduino:
            return True
        else:
            return self.connect()

    def checkconnection(self):
        textmessage = ""
        if self.connection_startup:
            # checks if in the first messages from ARDUINO the string "#Color Test LED" is included
            self.connection_startup_time -= 1 # is called every 100ms
            if self.connection_startup_time == 0:
            
                messagebox.showerror("Error when reading Arduino answer",
                                     "ARDUINO is not answering correctly.\n"
                                    "\n"
                                     "Check if the correct program is loaded to the arduino.\n"
                                     "It must be compiled with the compiler switch:\n"
                                     "  #define RECEIVE_LED_COLOR_PER_RS232")
                self.disconnect()
            else:
                while self.queue.qsize():
                    #print("process_serial: While loop")
                    try:
                        readtext = self.queue.get()
                        date_time = datetime.now()
                        d = date_time.strftime("%H:%M:%S")
                        readtext_str = readtext
                        textmessage = d + "  " + readtext_str
                        if not textmessage.endswith("\n"):
                            textmessage = textmessage +"\n"
                        if SerialIF_teststring2 in textmessage:
                            self.connection_startup = False                           
                            self.set_connectstatusmessage("Verbunden",fg="green")
                            dummy,maxLEDcnt_str=readtext_str.split(":")
                            #self.set_maxLEDcnt(int(maxLEDcnt_str))
                            #self.led_off()                                # 02.01.20:  Disabled because it generates sometimes a "Buffer overrun" on the Arduino
                            #self.led_off()                                #            In addition it doesn't work with out a "#begin"
                            break
                    except:
                        pass
        return textmessage
        
        
    def set_connectstatusmessage(self,status_text,fg="black"):
        self.statusmessage.configure(text="Status: " + status_text,fg=fg)

    def set_ARDUINOmessage(self,status_text,fg="black"):
        #self.statusmessage.configure(text=status_text,fg=fg)
        pass

    def send_to_ARDUINO(self, message,arduino=None):
        if arduino == None:
            arduino = self.arduino
        if arduino:
            try:
                arduino.write(message.encode())
                logging.info("Message send to ARDUINO: %s",message)
                self.queue.put( ">> " + str(message))
            except:
                logging.info("Error write message to ARDUINO")
    
    def set_maxLEDcnt(self,maxLEDcnt):
        self.maxLEDcnt = maxLEDcnt
        
    def get_maxLEDcnt(self):
        if self.maxLEDcnt:            
            return self.maxLEDcnt
        else:
            return self.getConfigData("maxLEDcount")
        
    def init_ledeffecttable(self):
        self.ledeffecttable.init_ledeffecttable()
 
    def init_ledeffecttable_entry(self,keystr):
        self.ledeffecttable.init_entry(keystr)
        
    def ledeffecttable_copy_leds(self,start_int,cnt_int,dest_int):
        self.ledeffecttable.copy_leds(start_int,cnt_int,dest_int)

    def ledeffecttable_init_entries(self,start_int,cnt_int):
        self.ledeffecttable.init_entries(start_int,cnt_int)
            
    def ledeffecttable_move_leds(self,start_int,cnt_int,dest_int):
        self.ledeffecttable.move_leds(start_int,cnt_int,dest_int)
        
    def ledeffecttable_insert_leds(self,start_int,cnt_int):
        self.ledeffecttable.insert_leds(start_int,cnt_int)

    def ledeffecttable_remove_leds(self,remove_start_int,cnt_int):
        self.ledeffecttable.remove_leds(remove_start_int,cnt_int)

                
    # ----------------------------------------------------------------
    # getframebyName
    # ----------------------------------------------------------------
    def getFramebyName (self, pagename):
        return self.tabdict.get(pagename,None)
    
    # ----------------------------------------------------------------
    # getStartPageClassName
    # ----------------------------------------------------------------
    def getStartPageClassName (self):
        startpagename = COMMAND_LINE_ARG_DICT.get("startpagename","")
        if not startpagename in self.tabdict.keys():
            startpagename=""
            logging.info("Commandline argument --startpage %s wrong. Allowed: %s",startpagename,repr(self.tabdict.keys()))
            
        if startpagename == "":
            startpagenumber = self.getConfigData("startpage")
            startpagename = startpageNumber2Name.get(startpagenumber,self.ConfigData.data.get("startpagename","ColorCheckPage"))
        return startpagename
    
    # ----------------------------------------------------------------
    # getStartPageClassIndex
    # ----------------------------------------------------------------
    def getStartPageClassIndex (self):
        startpagenumber = self.getConfigData("startpage")
        startpagename = startpageNumber2Name.get(startpagenumber,self.ConfigData.data.get("startpagename","ColorCheckPage"))
        startpageindex = tabClassName2Index.get(startpagename,"1")
        return startpageindex
    # ----------------------------------------------------------------
    # getTabNameList
    # ----------------------------------------------------------------
    def getTabNameList (self):

        return list(tabClassName2Name.values())
    
    # ----------------------------------------------------------------
    # getStartPageName
    # ----------------------------------------------------------------
    def getStartPageName(self, combolist_index):
        return tabIndex2ClassName.get(str(combolist_index),defaultStartPage)

    def call_helppage(self,event=None):
        filedir = os.path.dirname(os.path.realpath(__file__))
        helpfilename = filedir + "//" + HELPPAGE_FILENAME
        webbrowser.open_new_tab(helpfilename)

    def getConfigData(self, key):
        newkey = CONFIG2PARAMKEYS.get(key,key) # translate configdata key into paramdata key
        return self.ParamData.data.get(newkey,self.ConfigData.data.get(key,DEFAULT_CONFIG.get(key,""))) # return Paramdata for the key if available else ConfigData
    
    def getConfigData_multiple(self, configdatakey,paramkey,index):
        value = ""
        index_str = str(index)
        paramkey_dict = self.ConfigData.data.get(paramkey,{})
        if paramkey_dict != {}:
            configdatakey_dict = paramkey_dict.get(index_str,{})
            if configdatakey_dict != {}:
                value = configdatakey_dict.get(configdatakey,"")
        return value

   
    def readConfigData(self):
        filedir = os.path.dirname(os.path.realpath(__file__))
        self.ConfigData = ConfigFile(DEFAULT_CONFIG, CONFIG_FILENAME,filedir=filedir)
        self.ConfigData.data.update(COMMAND_LINE_ARG_DICT) # overwrite configdata mit commandline args
        self.ParamData = ConfigFile(DEFAULT_PARAM, PARAM_FILENAME,filedir=filedir)
        self.MacroDef = ConfigFile({},MACRODEF_FILENAME,filedir=filedir)
        logging.info(self.MacroDef.data)
        self.MacroParamDef = ConfigFile({},MACROPARAMDEF_FILENAME,filedir=filedir)
        logging.info(self.MacroParamDef.data)
        
    def setConfigData(self,key, value):
        self.ConfigData.data[key] = value
        
    def setConfigDataDict(self,param_dict):
        self.ConfigData.data.update(param_dict)  
    
    def setParamData(self,key, value):
        if self.ParamData.data:
            self.ParamData.data[key] = value

    def SaveConfigData(self):
        self.ConfigData.save()
        
    def SaveParamData(self):
        if self.ParamData.data:
            self.ParamData.save()
        
    def led_off(self,_event=None):
    # switch off all LED
        message = "#L00 00 00 00 FF\n"
        self.send_to_ARDUINO(message)
        
    def onCheckDisconnectFile(self):
        # checks every 1 Second if the file DISCONNECT_FILENAME is found.
        # if yes: then disconnect ARDUINO - is used by external program to request a disconnect of the ARDUINO
        #logging.info("onCheckDisconnectFile running")
        if os.path.isfile(DISCONNECT_FILENAME):
            self.led_off()
            self.disconnect()

            # delete the file to avoid a series of disconnects
            try:
                os.remove(DISCONNECT_FILENAME)
            except:
                pass

        if os.path.isfile(CLOSE_FILENAME):
            self.led_off()
            self.disconnect()
            self.cancel()

            # delete the file to avoid a series of disconnects
            try:
                os.remove(CLOSE_FILENAME)
            except:
                pass
        
        if self.continueCheckDisconnectFile:
            self.after(1000, self.onCheckDisconnectFile)


    def ToolTip(self, widget,text="", key="",button_1=False):
        if text:
            tooltiptext = text
        else:
            tooltiptext = _(TOOLTIPLIST.get(key,key))
        tooltip_var = None
        try:
            tooltip_var = widget.tooltip
        except:
            tooltip_var = None
            
        if tooltip_var==None:
            tooltip_var=Tooltip(widget, text=tooltiptext,button_1=button_1)
            widget.tooltip = tooltip_var
        else:
            tooltip_var.unschedule()
            tooltip_var.hide()
            tooltip_var.update_text(text)            
        return

    def addtoclipboard(self,text):
        self.root.clipboard_clear()
        # text to clipboard
        self.root.clipboard_append(text)
        
    def readfromclipboard(self):
        
        return self.root.clipboard_get()        

    def setroot(self, app):
        self.root=app
        
        
    def set_macroparam_var(self, macro, paramkey,variable,persistent=False):
        paramdict = self.macroparams_var.get(macro,{})
        if paramdict == {}:
            self.macroparams_var[macro] = {}
            self.macroparams_var[macro][paramkey] = variable
        else:
            paramdict[paramkey] = variable
        if persistent:
            if self.persistent_param_dict.get(macro,[]) !=[]:
                self.persistent_param_dict[macro] += [paramkey]
            else:
                self.persistent_param_dict[macro] = [paramkey]
            
    def get_macroparam_val(self, macro, paramkey):
        value = ""
        variable = self.macroparams_var[macro][paramkey]
        try:
            var_class = variable.winfo_class()
            if var_class == "TCombobox":
                # value of combobox needs to be translated into a generic value
                current_index = variable.current()
                if current_index == -1: # entry not in list
                    value = variable.get()
                else:
                    value_list = variable.keyvalues
                    value = value_list[current_index]
            else:
                value = variable.get()
        except:
            value = variable.get()
        return value     
            

    def get_macroparam_var_value(self, var,valuedict):
        
        paramconfig_dict = self.MacroParamDef.data.get(var.key,{})
        param_type = paramconfig_dict.get("Type","")
        
        if param_type == "":
            value = var.get()
            param_configname = paramconfig_dict.get("ConfigName","")
            valuedict[param_configname] = value                                        
        elif param_type == "Combo":
            current_index = var.current()
            if current_index == -1: # entry not in list
                value = var.get()
            else:
                value_list = var.keyvalues
                value = value_list[current_index]

            param_configname_list = paramconfig_dict.get("ConfigName","")
    
            if param_configname_list[0] != "":
                valuedict[param_configname_list[0]] = value
            if param_configname_list[1] != "":
                valuedict[param_configname_list[1]] = current_index
        return

            
    def get_macroparam_var_values(self, macro):
        valuedictmain = {}
        
        for macrokey in self.macroparams_var:
            valuedict = valuedictmain
            macro_components = macrokey.split(".")
            if macro_components[0] == macro:
                paramdict = self.macroparams_var.get(macrokey,{})
                if len(macro_components) > 1:
                    logging.info(macro_components)
                    valuedict2 = valuedict.get(macro_components[1],None)
                    if valuedict2 == None:
                        valuedict[macro_components[1]]={}
                        valuedict2 = valuedict.get(macro_components[1],None)
                    valuedict3 = valuedict2.get(macro_components[2],None)
                    if valuedict3 == None:
                        valuedict2[macro_components[2]]={}
                        valuedict3 = valuedict2.get(macro_components[2],None)
                    valuedict = valuedict3
                    
                if paramdict != {}:
                    
                    for paramkey in paramdict:
                        var = paramdict.get(paramkey,None)
                        if var != None:
                            self.get_macroparam_var_value(var,valuedict)
        valuedict = valuedictmain
        return valuedict
     
     
    def set_macroparam_val(self, macro, paramkey, value, disable = False):
        if value:
            try:
                macroparams_dict = self.macroparams_var.get(macro,{})
                        
                variable = macroparams_dict.get(paramkey,None)
                if variable:
                    if disable:
                        variable.config(state="normal")
                    var_class = variable.winfo_class()
                    if var_class == "TCombobox":
                        # value of combobox needs to be translated into a generic value
                        if isinstance(value,int):
                            current_index = value
                        else:
                            current_index = variable.keyvalues.index(value)
                        value = variable.textvalues[current_index]
                        variable.set(value)
                    elif var_class == "Entry" or var_class == "Text":
                        variable.delete(0.0,tk.END)
                        variable.insert(0.0,value)                        
                    else:          
                        variable.set(value)
                    if disable:
                        variable.config(state="disabled")                    
                else:
                    pass
            except: #limit_var has no winfo_class() function
                if variable:
                    variable.set(value)
        return
    
    def set_all_macroparam_val(self, macro, paramvalues):
        try:
            for paramkey in paramvalues:
                value = paramvalues.get(paramkey)
                if value:
                    self.set_macroparam_val(macro,paramkey,value)
                    if paramkey=="Group_Colour":
                        self.setgroupcolor(value)
        except:
            pass
        return
    
    def getConfigDatakey(self,paramkey):
        
        ConfigDatakey = paramkey
        paramconfig_dict = self.MacroParamDef.data.get(paramkey,{})
        param_type = paramconfig_dict.get("Type","")
        
        ConfigDatakey=[]
        
        if param_type == "Combo":
            ConfigDatakeyList = paramconfig_dict.get("ConfigName",[paramkey,paramkey])
            ConfigDatakey = ConfigDatakeyList[1]
        else:
            ConfigDatakey = paramconfig_dict.get("ConfigName",paramkey)
        return ConfigDatakey
    
    
    def create_macroparam_content(self,parent_frame, macro, macroparams,extratitleline=False,maxcolumns=5, startrow=0, minrow=4, style="MACROPage"):
        
        if style =="MACROPage":
        
            MACROLABELWIDTH = 15
            MACRODESCWIDTH = 20
            MACRODESCWRAPL = 120
            
            PARAMFRAMEWIDTH = 105
            
            PARAMLABELWIDTH = 15
            PARAMLABELWRAPL = 100        
            
            PARAMSPINBOXWIDTH = 6
            PARAMENTRWIDTH = 16
            PARAMCOMBOWIDTH = 16
         
            STICKY = "nw"
            ANCHOR = "center"
            
        elif style == "CONFIGPage":
            MACROLABELWIDTH = 15*2
            MACRODESCWIDTH = 20*2
            MACRODESCWRAPL = 120*2
            
            PARAMFRAMEWIDTH = 105
            
            PARAMLABELWIDTH = 15
            PARAMLABELWRAPL = 100       
            
            PARAMSPINBOXWIDTH = 6
            PARAMENTRWIDTH = 16
            PARAMCOMBOWIDTH = 16
         
            STICKY = "w"
            ANCHOR = "e"
            
        if extratitleline:
            titlerow=0
            valuerow=1
            titlecolumn=0
            valuecolumn=0
            deltarow = 2
            deltacolumn = 1
        else:
            titlerow = 0
            valuerow = 0
            titlecolumn = 0
            valuecolumn = 1
            deltarow = 1
            deltacolumn = 2
        
        column = 0
        row = startrow
    
        for paramkey in macroparams:
            paramconfig_dict = self.MacroParamDef.data.get(paramkey,{})
            param_min = paramconfig_dict.get("Min",0)
            param_max = paramconfig_dict.get("Max",255)
            param_title = paramconfig_dict.get("Input Text","")
            param_tooltip = paramconfig_dict.get("Hint","")
            param_persistent = (paramconfig_dict.get("Persistent","False") == "True")
            param_configname = paramconfig_dict.get("ConfigName",paramkey)
            param_default = paramconfig_dict.get("Default","")
            param_value_change_event = (paramconfig_dict.get("ValueChangeEvent","False") == "True")
            if param_persistent:
                configData = self.getConfigData(paramkey)
                if configData != "":
                    param_default = configData
            param_readonly = (paramconfig_dict.get("ReadOnly","False") == "True")
            param_type = paramconfig_dict.get("Type","")
    
            if param_title == "":
                param_title = paramkey
                
            if param_type == "": # number value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                if param_max == "":
                    param_max = 255
                paramvar = LimitVar(param_min, param_max, parent_frame)
                paramvar.set(param_default)
                paramvar.key = paramkey
                
                if param_value_change_event:
                    s_paramvar = Spinbox(parent_frame, from_=param_min, to=param_max, width=PARAMSPINBOXWIDTH, name='spinbox', textvariable=paramvar,command=lambda:self._update_value(macro,paramkey))
                else:
                    s_paramvar = Spinbox(parent_frame, from_=param_min, to=param_max, width=PARAMSPINBOXWIDTH, name='spinbox', textvariable=paramvar)
                s_paramvar.delete(0, 'end')
                s_paramvar.insert(0, param_default)
                s_paramvar.grid(row=row+valuerow, column=column+valuecolumn, padx=2, pady=2, sticky=STICKY)
                s_paramvar.key = paramkey
                
                param_bind_up   = paramconfig_dict.get("Key_Up","")
                param_bind_down = paramconfig_dict.get("Key_Down","")
                
                if param_bind_up != "":
                    self.bind(param_bind_up,s_paramvar.invoke_buttonup)
                    s_paramvar.key_up=param_bind_up
                    if self.bind_keys_dict.get(macro,{})=={}:
                        self.bind_keys_dict[macro] = {}
                    self.bind_keys_dict[macro][paramkey] = s_paramvar
                if param_bind_down != "":    
                    self.bind(param_bind_down,s_paramvar.invoke_buttondown)
                    s_paramvar.key_down=param_bind_down
                    self.bind_keys_dict[macro][paramkey] = s_paramvar
            
                self.set_macroparam_var(macro, paramkey, paramvar,persistent=param_persistent)
                
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow                    
                
            elif param_type == "Time": # Time value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                
                paramvar = tk.Entry(parent_frame,width=PARAMENTRWIDTH)
                paramvar.delete(0, 'end')
                paramvar.insert(0, param_default)
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
            
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow      
                    
            elif param_type == "String": # String value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                
                paramvar = tk.Entry(parent_frame,width=PARAMENTRWIDTH)
                     
                if param_value_change_event:
                    paramvar.bind("<Return>",self._key_return)                

                paramvar.delete(0, 'end')
                paramvar.insert(0, param_default)
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                paramvar.macro = macro
                
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow
            
            elif param_type == "BigEntry": # Text value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                paramvar = tk.Entry(parent_frame,width=PARAMENTRWIDTH*3)
                
                if param_value_change_event:
                    paramvar.bind("<Return>",self._key_return)
                                    
                paramvar.delete(0, 'end')
                paramvar.insert(0, param_default)
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                paramvar.macro = macro
            
                self.set_macroparam_var(macro, paramkey, paramvar)                

                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow            
            
            elif param_type == "Text": # Text value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                paramvar = tk.Text(parent_frame,width=PARAMENTRWIDTH*3,height=2)
                paramvar.delete("1.0", "end")
                paramvar.insert("end",param_default)
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                
                if param_readonly:
                    paramvar.state = "disabled"
            
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow            
                    
            elif param_type == "Checkbutton": # Checkbutton param
                paramvar = tk.IntVar()
                paramvar.key = paramkey
                 
                label=tk.Checkbutton(parent_frame, text=param_title,width=PARAMLABELWIDTH*2,wraplength = PARAMLABELWRAPL*2,variable=paramvar)
                label.grid(row=row+valuerow, column=column, columnspan=2,sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)                
            
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow
    
                
            elif param_type == "Combo": # Combolist param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                
                paramvar = ttk.Combobox(parent_frame, state="readonly", width=PARAMCOMBOWIDTH)
                combo_value_list = paramconfig_dict.get("KeyValues",paramconfig_dict.get("Values",[]))
                combo_text_list = paramconfig_dict.get("ValuesText",[])
                
                if combo_text_list == []:
                    paramvar["value"] = combo_value_list
                else:
                    paramvar["value"] = combo_text_list
                    
                paramvar.current(0) #set the selected view                    
                
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                paramvar.keyvalues = combo_value_list
                paramvar.textvalues = combo_text_list
            
                self.set_macroparam_var(macro, paramkey, paramvar)               
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow      
                    
            elif param_type == "GroupCombo": # Combolist param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                paramvar = ttk.Combobox(parent_frame, width=PARAMCOMBOWIDTH,postcommand=self.update_GroupComboValues)
                combo_value_list = list(self.ledgrouptable.keys())
                combo_text_list = []
                
                if combo_text_list == []:
                    paramvar["value"] = combo_value_list
                else:
                    paramvar["value"] = combo_text_list
                    
                paramvar.current(0) #set the selected view                    
                
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                paramvar.keyvalues = combo_value_list
                paramvar.textvalues = combo_text_list
                paramvar.bind("<<ComboboxSelected>>", self.GroupComboSelected)
            
                self.set_macroparam_var(macro, paramkey, paramvar)               
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow                          
                    
            elif param_type == "CX": # Channel value param
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                paramvar = ttk.Combobox(parent_frame, width=PARAMCOMBOWIDTH)
                
                combo_value_list = paramconfig_dict.get("KeyValues",paramconfig_dict.get("Values",("C_All", "C12", "C23", "C1", "C2", "C3", "C_RED", "C_GREEN", "C_BLUE", "C_WHITE", "C_YELLOW", "C_CYAN")))
                combo_text_list = paramconfig_dict.get("ValuesText",[])
                
                if combo_text_list == []:
                    paramvar["value"] = combo_value_list
                else:
                    paramvar["value"] = combo_text_list                    
                
                paramvar.current(0) #set the selected colorview                    
                
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, columnspan=1, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
                paramvar.keyvalues = combo_value_list
                paramvar.textvalues = combo_text_list
            
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow      
            
    
            elif param_type == "Multipleparams": # Multiple params
                logging.info ("%s - %s",macro,param_type)
                if row >1 or column>0: 
                    row += deltarow
                    column = 0
                
                label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,anchor=ANCHOR)
                label.grid(row=row+titlerow, column=column+titlecolumn, rowspan=2, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(label, text=param_tooltip)
                
                repeat_number = paramconfig_dict.get("Repeat","")
                
                if repeat_number == "":
                
                    multipleparam_frame = ttk.Frame(parent_frame)
                    multipleparam_frame.grid(row=row,column=column+1 ,columnspan=6,sticky='nesw', padx=0, pady=0)
                    
                    multipleparams = paramconfig_dict.get("MultipleParams",[])
                    
                    if multipleparams != []:
                        if style != "CONFIGPage":
                            self.create_macroparam_content(multipleparam_frame,macro, multipleparams,extratitleline=extratitleline,maxcolumns=maxcolumns-1,minrow=0,style=style)
                            separator = ttk.Separator (parent_frame, orient = tk.HORIZONTAL)
                            separator.grid (row = row+2, column = 0, columnspan= 10, padx=2, pady=2, sticky = "ew")
                        else:
                            self.create_macroparam_content(multipleparam_frame,macro, multipleparams,extratitleline=extratitleline,maxcolumns=6,minrow=0,style=style)
                            
           
                    column = 0
                    row=row+3
                    
                else:
                    repeat_number_int = int(repeat_number)
                    
                    repeat_max_columns = 6
                    
                    for i in range(repeat_number_int):
                        repeat_macro=macro+"."+paramkey+"."+str(i)

                        multipleparam_frame = ttk.Frame(parent_frame)
                        multipleparam_frame.grid(row=row,column=column+1 ,columnspan=10,sticky='nesw', padx=0, pady=0)
                        
                        multipleparams = paramconfig_dict.get("MultipleParams",[])
                        
                        if multipleparams != []:
                            self.create_macroparam_content(multipleparam_frame,repeat_macro, multipleparams,extratitleline=extratitleline,maxcolumns=repeat_max_columns,minrow=0,style=style)
               
                        column = 0
                        row=row+1
                
            elif param_type == "Color": # Color value param
                
                self.colorlabel = tk.Button(parent_frame, text=param_title, width=PARAMLABELWIDTH, height=2, wraplength=PARAMLABELWRAPL,relief="raised", background=param_default,borderwidth=1,command=self.choosecolor)
                #label=tk.Label(parent_frame, text=param_title,width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL,bg=param_default,borderwidth=1)
                self.colorlabel.grid(row=row+titlerow, column=column+titlecolumn, sticky=STICKY, padx=2, pady=2)
                self.ToolTip(self.colorlabel, text=param_tooltip)
                
                paramvar = tk.Entry(parent_frame,width=PARAMENTRWIDTH)
                paramvar.delete(0, 'end')
                paramvar.insert(0, param_default)
                paramvar.grid(row=row+valuerow, column=column+valuecolumn, sticky=STICKY, padx=2, pady=2)
                paramvar.key = paramkey
            
                self.set_macroparam_var(macro, paramkey, paramvar)                
    
                column = column + deltacolumn
                if column > maxcolumns:
                    column = 0
                    row=row+deltarow
            
            if param_readonly:
                paramvar.state = "DISABLED"            
        
        if (column<maxcolumns+1) and (column>0):
            for i in range(column,maxcolumns+1):
                label=tk.Label(parent_frame, text=" ",width=PARAMLABELWIDTH,height=2,wraplength = PARAMLABELWRAPL)
                label.grid(row=row,column=i,sticky=STICKY, padx=2, pady=2)
        
        if maxcolumns > 6:        
            seplabel=tk.Label(parent_frame, text="",width=90,height=1)
            seplabel.grid(row=row+2, column=0, columnspan=10,sticky='ew', padx=2, pady=2)
                
    
    def create_macroparam_frame(self,parent_frame, macro, extratitleline=False,maxcolumns=5, startrow=0, minrow=4,style="MACROPage"):
        
        MACROLABELWIDTH = 15
        MACRODESCWIDTH = 20
        MACRODESCWRAPL = 120
        BUTTONLABELWIDTH = 10
        
        PARAMFRAMEWIDTH = 105
        
        PARAMLABELWIDTH = 15
        PARAMLABELWRAPL = 100        
        
        PARAMSPINBOXWIDTH = 4
        PARAMENTRWIDTH = 8
        PARAMCOMBOWIDTH = 16
        
        macroparam_frame = ttk.Frame(parent_frame, relief="ridge", borderwidth=1)
        self.macroparam_frame_dict[macro] = macroparam_frame
    
        macrodata = self.MacroDef.data.get(macro,{})
        Macrotitle = macro
        
        Macrolongdescription = macrodata.get("Ausführliche Beschreibung","")
        Macrodescription = macrodata.get("Kurzbeschreibung","")
        
        if Macrolongdescription =="":
            Macrolongdescription = Macrodescription
        macroldlabel = tk.Text(macroparam_frame, wrap='word', bg=self.cget('bg'), borderwidth=2,relief="ridge",width=108,height=5,font=SMALL_FONT)
        
        macroldlabel.delete("1.0", "end")
        macroldlabel.insert("end", Macrolongdescription)
        macroldlabel.yview("1.0")
        macroldlabel.config(state = tk.DISABLED)
        
        if style == "MACROPage":
            macroldlabel.grid(row=4, column=0, columnspan=2,padx=0, pady=0,sticky="w")
            macrolabel = tk.Button(macroparam_frame, text=Macrotitle, width=MACROLABELWIDTH, height=2, wraplength=150,relief="raised", background="white",borderwidth=1,command=lambda: self._macro_cmd(macrokey=macro))
            macrolabel.grid(row=1, column=0, sticky="nw", padx=4, pady=4)
            macrolabel.key=macro
            self.ToolTip(macrolabel, text=Macrodescription)
        else:
            macroldlabel.grid(row=0, column=0, columnspan=2,padx=10, pady=10,sticky="we",)
       
        macrotype = macrodata.get("Typ","")
        if macrotype =="ColTab":
            macroparams = []
        else:       
            macroparams = macrodata.get("Params",[])
        
        if macroparams:
            param_frame = ttk.Frame(macroparam_frame) #,borderwidth=1,relief="ridge")
                                  
            self.create_macroparam_content(param_frame,macro, macroparams,extratitleline=extratitleline,maxcolumns=maxcolumns,startrow=startrow,style=style)
    
            param_frame.grid(row=1,column=1,rowspan=2,padx=0, pady=0,sticky="nw")
    
        return macroparam_frame
    
    def _macro_cmd(self, macrokey=""):
        """Respond to user click on a macro label item in macrolist."""
        
        self.macro = macrokey
        macroparams = self.get_all_macroparam_val(macrokey)
        self.hexa = macroparams.get("Group_Colour","")
        self.group_name_str = self.get_all_group_params()
        self._update_ledtable(self.lednum_int, int(self.ledcount_int),self.hexa,"",macrokey, self.group_name_str, params=macroparams)
        self.update_ledtable_complete()    
    
    def update_GroupComboValues(self):
        
        combo_value_list = list(self.ledgrouptable.keys())
        combo_text_list = []
        
        paramvar = self.macroparams_var["Group"]["Group_Name"]
        paramvar["value"] = combo_value_list

        paramvar.keyvalues = combo_value_list
        paramvar.textvalues = combo_text_list
        
    def GroupComboSelected(self,event):
        
        #paramvar = self.macroparams_var["Group"]["Group_Name"]
        paramvar = event.widget
        
        groupname = paramvar.get()
        
        group_dict = self.ledgrouptable.get(groupname,{})
        group_param_dict = group_dict.get("params",{})
        if group_param_dict != {}:
            self.set_all_macroparam_val("Group",group_param_dict)
    
    def setgroupcolor(self,color):
        
        self.colorlabel.config(bg=color)
        paramvar = self.macroparams_var["Group"]["Group_Colour"]
        paramvar.delete(0, 'end')
        paramvar.insert(0, color)    
    
    def choosecolor(self):
        paramvar = self.macroparams_var["Group"]["Group_Colour"]
        old_color=paramvar.get()        
        color = colorchooser.askcolor(color=old_color)
        
        if color:
            colorhex = color[1]
            self.setgroupcolor(colorhex)    


    def _key_return(self,event=None):
        
        param = event.widget
        self._update_value(param.macro,param.key)
    
        
        #tabframe=self.getFramebyName(macro)
        #if tabframe!=None:
        #    tabframe._update_value(paramkey)


    def _update_value(self,macro,paramkey):
        logging.info("update_value: %s - %s",macro,paramkey)
        tabframe=self.getFramebyName(macro)
        if tabframe!=None:
            tabframe._update_value(paramkey)
    
    def process_serial(self):

        #print("process_serial: Start")
        textmessage = self.checkconnection()
        if textmessage:
            #self.text.insert("end", textmessage)
            #self.text.yview("end")
            #self.set_ARDUINOmessage(textmessage)
            pass
        else:
            if self.queue:
                while self.queue.qsize():
                    #print("process_serial: While loop")
                    try:
                        readtext = self.queue.get()
                        date_time = datetime.now()
                        d = date_time.strftime("%H:%M:%S")
                        textmessage = d + "  " + readtext
                        if not textmessage.endswith("\n"):
                            textmessage = textmessage +"\n"
                        #write message into text window
                        #self.text.insert("end", textmessage)
                        #self.text.yview("end")
                        #self.set_ARDUINOmessage(textmessage)
                    except IOError:
                        pass
            
        if self.monitor_serial:
            self.after(100, self.process_serial)

    def start_process_serial_all(self):
        global ThreadEvent
        ThreadEvent = threading.Event()
        ThreadEvent.set()
        time.sleep(2)
        ThreadEvent.clear()
        self.monitor_serial = True
        for port in self.serial_port_dict:
            arduino = self.serial_port_dict[port]["ARDUINO"]
            self.thread = SerialThread(self.queue,arduino,p_serialportname=port)
        self.thread.start()
        self.process_serial()

    def stop_process_serial_all(self):
        global ThreadEvent
        self.monitor_serial = False
        if ThreadEvent:
            ThreadEvent.set()
        #time.sleep(1)


class SerialThread(threading.Thread):
    def __init__(self, p_queue, p_serialport,p_serialportname=""):
        #global serialport
        threading.Thread.__init__(self)
        self.queue = p_queue
        self.serialport = p_serialport
        self.serialport_name = p_serialportname

    def run(self):
        #global serialport
        logging.info("SerialThread started:"+self.serialport_name)
        if self.serialport:

            while not ThreadEvent.is_set() and self.serialport:
                # print("Event:",ThreadEvent.is_set())
                # print("Serialport:", serialport)
                # logging.info("SerialThread while loop")
                #logging.info("SerialThread running")
                try:
                    text = self.serialport.readline()
                except:
                    text = ""
                
                if len(text)>0:
                    try:
                        self.queue.put(text.decode('utf-8'))
                    except:
                        pass
                    logging.info("SerialThread (%s) got message: %s", self.serialport_name,text)

        logging.info("SerialThread (%s) received event. Exiting", self.serialport_name)



#-------------------------------------------

COMMAND_LINE_ARG_DICT = {}

parser = argparse.ArgumentParser(description='Generate MLL Programs')
parser.add_argument('--loglevel')
parser.add_argument('--startpage')
parser.add_argument('--port')
args = parser.parse_args()

format = "%(asctime)s: %(message)s"

if args.loglevel:
    logging_level = args.loglevel.upper()
    if logging_level=="DEBUG":
        logging.basicConfig(format=format, level=logging.DEBUG,datefmt="%H:%M:%S")
    elif logging_level=="INFO":
        logging.basicConfig(format=format, level=logging.INFO,datefmt="%H:%M:%S")
    elif logging_level=="WARNING":
        logging.basicConfig(format=format, level=logging.WARNING,datefmt="%H:%M:%S")
    elif logging_level=="ERROR":
        logging.basicConfig(format=format, level=logging.ERROR,datefmt="%H:%M:%S")
    else:
        logging.basicConfig(format=format, level=logging.CRITICAL,datefmt="%H:%M:%S")
else:
    logging.basicConfig(format=format, level=logging.ERROR,datefmt="%H:%M:%S")

logging.info("MLL Proggenerator started")

if args.startpage:
    COMMAND_LINE_ARG_DICT["startpagename"]=args.startpage
        
if args.port:
    COMMAND_LINE_ARG_DICT["serportname"]=args.port

app = LEDColorTest()



app.setroot(app)

app.protocol("WM_DELETE_WINDOW", app.cancel)

if app.getConfigData("autoconnect"):
    app.connect()

app.mainloop()


