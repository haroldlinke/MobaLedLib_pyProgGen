# -*- coding: utf-8 -*-
#
#         MobaLedCheckColors: Color checker for WS2812 and WS2811 based MobaLedLib
#
#         ServoTestPage
#
# * Version: 1.00
# * Author: Harold Linke
# * Date: December 25th, 2019
# * Copyright: Harold Linke 2019
# *
# *
# * MobaLedCheckColors on Github: https://github.com/haroldlinke/MobaLedCheckColors
# *
# *
# * History of Change
# * V1.00 25.12.2019 - Harold Linke - first release
# *
# *
# * MobaLedCheckColors supports the MobaLedLib by Hardi Stengelin
# * https://github.com/Hardi-St/MobaLedLib
# *
# * MobaLedCheckColors is free software: you can servo_0istribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * MobaLedCheckColors is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program.  If not, see <http://www.gnu.org/licenses/>.
# *
# * MobaLedCheckColors is based on tkColorPicker by Juliette Monsel
# * https://sourceforge.net/projects/tkcolorpicker/
# *
# * tkcolorpicker - Alternative to colorchooser for Tkinter.
# * Copyright 2017 Juliette Monsel <j_4321@protonmail.com>
# *
# * tkcolorpicker is free software: you can servo_0istribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * tkcolorpicker is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with this program.  If not, see <http://www.gnu.org/licenses/>.
# *
# * The code for changing pages was derived from: http://stackoverflow.com/questions/7546050/switch-between-two-frames-in-tkinter
# * License: http://creativecommons.org/licenses/by-sa/3.0/
# ***************************************************************************

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkcolorpicker.spinbox import Spinbox
from tkcolorpicker.limitvar import LimitVar

from mlpyproggen.DefaultConstants import COLORCOR_MAX, DEFAULT_PALETTE, LARGE_FONT, SMALL_FONT, VERY_LARGE_FONT, VERSION, PERCENT_BRIGHTNESS, BLINKFRQ
#from mlpyproggen.dictFile import saveDicttoFile, readDictFromFile
import mlpyproggen.dictFile as dictFile
from locale import getdefaultlocale
import re
import time
import logging

PERCENT_BRIGHTNESS = 1  # 1 = Show the brightnes as percent, 0 = Show the brightnes as ">>>"# 03.12.19:

COLORCOR_MAX = 255

ARDUINO_WAITTIME = 0.5        
# ----------------------------------------------------------------
# Class ServoTestPage
# ----------------------------------------------------------------

class ServoTestPage(tk.Frame):

    # ----------------------------------------------------------------
    # ServoTestPage __init__
    # ----------------------------------------------------------------

    def __init__(self, parent, controller):
        
        tk.Frame.__init__(self, parent)
        
        self.tabClassName = "ServoTestPage"
        tk.Frame.__init__(self,parent)
        self.controller = controller
        macrodata = self.controller.MacroDef.data.get(self.tabClassName,{})
        self.tabname = macrodata.get("MTabName",self.tabClassName)
        self.title = macrodata.get("Title",self.tabClassName)
        
        #button1_text = macrodata.get("Button_1",self.tabClassName)
        #button2_text = macrodata.get("Button_2",self.tabClassName)        

        self.main_frame = ttk.Frame(self, relief="ridge", borderwidth=2)
        self.main_frame.pack(expand=1,fill="both")
        
        title_frame = ttk.Frame(self.main_frame, relief="ridge", borderwidth=2)

        label = ttk.Label(title_frame, text=self.title, font=LARGE_FONT)
        label.pack(padx=5,pady=(5,5))
        
        config_frame = self.controller.create_macroparam_frame(self.main_frame,self.tabClassName, maxcolumns=4,startrow =1,style="CONFIGPage")        
                
        self.on_lednum = 0

        led = self.getConfigData("lastLed")

        serport = controller.arduino

        self.tab_frame = ttk.Frame(self.main_frame,borderwidth=1,relief="ridge")

        #direct control frame for servos
        direct_control_frame = ttk.Frame(self.tab_frame,relief="ridge", borderwidth=2)
     
        servo_direct_position_frame = ttk.Frame(direct_control_frame, relief="ridge", borderwidth=2)
        servo_direct_position_frame.grid(row=0, column=0, padx=10, pady=10,sticky="")
        
        #dc_label1 = ttk.Label(servo_direct_position_frame, text='Servo Direct Control').grid(row=0, column=0, sticky='w', padx=4, pady=4)
     
        servo_direct_position_frame.columnconfigure(0, weight=1)

        self.servo_pos_var = tk.DoubleVar()
        self.servo_pos_var.set(0)
        #self.servo_scale = ttk.Scale( servo_direct_position_frame, variable = self.servo_pos_var,command=self._update_servo_position,from_=0,to=220,orient=tk.HORIZONTAL,length=440)
        self.servo_scale = tk.Scale( servo_direct_position_frame, variable = self.servo_pos_var,command=self._update_servo_position,from_=0,to=220,orient=tk.HORIZONTAL,length=440,label="Servo position",tickinterval=20)
        self.servo_scale.grid(row=0,column=0,sticky="")  
        self.controller.ToolTip(self.servo_scale, text="Position of Servo 1..220\nAnklicken zum Aktivieren der Tasten:\n[Right]/[Left]\n - single step\n[CTRL-Right]/[CTRL-Left]\n - long step\n[Pos1]/[Ende}\n - Anfang/Ende\n"+
                                "\nKlicken auf dem Sliderfeld:\n<Linke Taste>\n - single step vorwärts/rückwärts\n<Rechte Taste>\n - spring zum angeklickten Wert\n<CTRL Linke Taste>\n - springe zum Anfang/Ende")
        self.servo_scale.focus_set()
        self.servo_scale.bind("<Button-1>", self.servo_scale_focus_set)
        
        # constants
        select_servo0 = 225
        select_servo1 = 230
        select_servo2 = 235
        
        select_set_min_max_pos = 240
        
        select_set_speed = 245
        
        set_speed_by_button = 250
        
        save_changes = 254
        
        save_position = 205
        
        back_to_normal = 0
        
        lowPos = 1
        
        high_pos = 220
        
        button_frame = ttk.Frame(self.tab_frame,relief="ridge", borderwidth=2,width=500)
        
        servo_program_frame =ttk.Frame(self.tab_frame,relief="ridge", borderwidth=2,width=500)
        sp_label1 = ttk.Label(servo_program_frame, text='Servo Programmieren').grid(row=0, column=0, sticky='w',padx=4, pady=4)
        
        # ------------ SERVO Speed 
        servo_set_speed_frame = ttk.Frame(servo_program_frame,relief="ridge", borderwidth=2,width=500)
        sss_label1 = ttk.Label(servo_set_speed_frame, text='Servo Geschwindigkeit programmieren')
        sss_label1.grid(row=0, column=0, sticky='w',padx=4, pady=4)
        
        button_start_set_speed=ttk.Button(servo_set_speed_frame, text="Start Geschwindigkeitprogrammierung",width=40, command=self._start_set_servo_speed)
        button_start_set_speed.grid(row=1, column=0, columnspan=2,padx=10, pady=10, sticky='w')
        self.controller.ToolTip(button_start_set_speed, text="Startet die Geschwindigkeitsprogrammierung")        
        
        self.v_speed_0 = LimitVar(1, 220, self)
        self.s_speed_0 = Spinbox(servo_set_speed_frame, from_=1, to=220, width=5, name='spinbox', textvariable=self.v_speed_0, command=self._update_servo_speed)
        self.s_speed_0.delete(0, 'end')
        self.s_speed_0.insert(0, "100")
        self.s_speed_0.grid(row=2, column=1, sticky='w', padx=4, pady=4)
        self.sss_label = ttk.Label(servo_set_speed_frame, text=' ',background="white",width=60)
        self.sss_label.grid(row=2, column=0, sticky='e', padx=4, pady=4)
        self.controller.ToolTip(self.s_speed_0, text="Geschwindigkeit des Servo 1..220")
        
        button_end_set_speed=ttk.Button(servo_set_speed_frame, text="Beende Geschwindigkeitprogrammierung",width=40, command=self._end_set_servo_speed)
        button_end_set_speed.grid(row=3, column=0, columnspan=2, padx=10, pady=10, sticky='w')
        self.controller.ToolTip(button_end_set_speed, text="Beendet die Geschwindigkeitprogrammierung und speichert den Wert")        
        
        # ------------- SERVO Pos
        servo_set_pos_frame = ttk.Frame(servo_program_frame,relief="ridge", borderwidth=2,width=500)
        ssp_label1 = ttk.Label(servo_set_pos_frame, text='Min and Max Position programmieren')
        ssp_label1.grid(row=0, column=0, sticky='w',padx=4, pady=4)
       
        self.button_start_set_mm_pos=ttk.Button(servo_set_pos_frame, text="Start Min/Max Pos programmieren",width=40, command=self._start_set_min_max_pos)
        self.button_start_set_mm_pos.grid(row=1, column=0, columnspan=2,padx=10, pady=10, sticky='w')
        self.controller.ToolTip(self.button_start_set_mm_pos, text="Startet die Min/Max Positionsprogrammierung")
        
        self.status = "Save Min Pos"

        self.ssp_label2 = ttk.Label(servo_set_pos_frame, text="",width=60)
        self.ssp_label2.grid(row=2, column=0, sticky='w',padx=4, pady=4)
        
        self.button_start_save_mm_pos=ttk.Button(servo_set_pos_frame, text="Beende Min Pos programmieren",width=40, command=self._save_min_max_pos)
        self.button_start_save_mm_pos.grid(row=3, column=0, columnspan=2,padx=10, pady=10, sticky='w')
        self.controller.ToolTip(self.button_start_save_mm_pos, text="Speichert die aktuelle Position und geht zum nächsten Schritt bzw \nBeendet die Min/Max Positionsprogrammierung und speichert die Werte")
        
        servo_set_pos_frame.grid(row=3, column=0, pady=10, padx=10, sticky="w")
        servo_set_speed_frame.grid(row=3, column=1, pady=10, padx=10, sticky="e")
        
        # ------------------- buttons
        """
        label1 = ttk.Label(button_frame, text='(Only for testing\nStep 1 - Select Servo').grid(row=1, column=0, sticky='e',
                                                 padx=4, pady=4)
        
        button1=ttk.Button(button_frame, text="T225 Sel Servo 1",width=20, command=lambda: self.servo_prog_button(code=225))
        button1.grid(row=1, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button1, text="Taster1\n[CTRL-o]")

        button2=ttk.Button(button_frame, text="T230 Sel Servo 2",width=20, command=lambda: self.servo_prog_button(code=230))
        button2.grid(row=1, column=2, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button2, text="Taster2")
        
        button3=ttk.Button(button_frame, text="T235 Sel Servo 3",width=20, command=lambda: self.servo_prog_button(code=235))
        button3.grid(row=1, column=3, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button3, text="Taster1\n[CTRL-o]")

        label2 = ttk.Label(button_frame, text='Step 2 - Select Task').grid(row=2, column=0, sticky='e',
                                                 padx=4, pady=4)

        button4=ttk.Button(button_frame, text="T240 Set Min/Max",width=20, command=lambda: self.servo_prog_button(code=240))
        button4.grid(row=2, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button4, text="Taster2")
        
        button5=ttk.Button(button_frame, text="T245 Set Speed",width=20, command=lambda: self.servo_prog_button(code=245))
        button5.grid(row=2, column=3, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button5, text="Taster1\n[CTRL-o]")

        button6=ttk.Button(button_frame, text="T250 Start",width=20, command=lambda: self.servo_prog_button(code=250))
        button6.grid(row=3, column=2, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button6, text="Taster2")
        

        label3 = ttk.Label(button_frame, text='Step 3 - Set Min').grid(row=4, column=0, sticky='e',
                                                 padx=4, pady=4)
        
        label4 = ttk.Label(button_frame, text='Step 4 - Set Max').grid(row=5, column=0, sticky='e',
                                                 padx=4, pady=4)

        button9=ttk.Button(button_frame, text="T9 (205) Next step",width=20, command=lambda: self.servo_prog_button(code=205))
        button9.grid(row=5, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button9, text="Taster2")

        label5 = ttk.Label(button_frame, text='Step 5 - use <<,<,>,>> to Set Max').grid(row=6, column=0, sticky='e',
                                                 padx=4, pady=4)

        label6 = ttk.Label(button_frame, text='Step 6 - Store Max').grid(row=7, column=0, sticky='e',
                                                 padx=4, pady=4)
        button9a=ttk.Button(button_frame, text="T205 Next step",width=20, command=lambda: self.servo_prog_button(code=205))
        button9a.grid(row=7, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button9a, text="Taster2")

        label6 = ttk.Label(button_frame, text='Step 6 - save and end').grid(row=8, column=0, sticky='e',
                                                 padx=4, pady=4)
        button10=ttk.Button(button_frame, text="T254 Save",width=20, command=lambda: self.servo_prog_button(code=254))
        button10.grid(row=8, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button10, text="Taster2")
        
        button11=ttk.Button(button_frame, text="T0 Back to normal",width=20, command=lambda: self.servo_prog_button(code=0))
        button11.grid(row=9, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button10, text="Taster2")                    
        
        button12=ttk.Button(button_frame, text="T220 High Pos",width=20, command=lambda: self.servo_prog_button(code=220))
        button12.grid(row=10, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button12, text="Taster2")
        
        button13=ttk.Button(button_frame, text="T10 Low Pos",width=20, command=lambda: self.servo_prog_button(code=10))
        button13.grid(row=10, column=3, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button13, text="Taster2")
        """
        
        set_button_frame = ttk.Frame(servo_program_frame, relief="ridge", borderwidth=2)

        button7=tk.Label(set_button_frame, text="Dec <<",width=15,fg="grey",relief="raised")
        button7.grid(row=4, column=1, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button7, text="T60 Dec <<")
        button7.bind("<ButtonRelease-1>",lambda event: self.servo_prog_label_released(event=event))
        button7.bind("<Button-1>",lambda event: self.servo_prog_label_pressed(event=event,code=60))
        
        button7a=tk.Label(set_button_frame, text="Dec <",width=15,fg="grey",relief="raised")
        button7a.grid(row=4, column=2, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button7a, text="T90 Dec <<")
        button7a.bind("<ButtonRelease-1>",lambda event: self.servo_prog_label_released(event=event))
        button7a.bind("<Button-1>",lambda event: self.servo_prog_label_pressed(event=event,code=90))        
        
        #button7b=ttk.Button(set_button_frame, text="Stop",width=15, command=lambda: self.servo_prog_button(code=100))
        #button7b.grid(row=4, column=3, padx=10, pady=(10, 4), sticky='w')
        #self.controller.ToolTip(button7b, text="T100 Stop")
        
        button8=tk.Label(set_button_frame, text="Inc >",width=15,fg="grey",relief="raised")
        button8.grid(row=4, column=3, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button8, text="T110 Dec <<")
        button8.bind("<ButtonRelease-1>",lambda event: self.servo_prog_label_released(event=event))
        button8.bind("<Button-1>",lambda event: self.servo_prog_label_pressed(event=event,code=110))
        
        button8a=tk.Label(set_button_frame, text="Inc >>",width=15,fg="grey",relief="raised")
        button8a.grid(row=4, column=4, padx=10, pady=(10, 4), sticky='w')
        self.controller.ToolTip(button8a, text="T140 Dec <<")
        button8a.bind("<ButtonRelease-1>",lambda event: self.servo_prog_label_released(event=event))
        button8a.bind("<Button-1>",lambda event: self.servo_prog_label_pressed(event=event,code=140))               


        # --- placement
        # main_frame
        title_frame.grid(row=0, column=0, pady=10, padx=10)
        config_frame.grid(row=1, column=0, pady=10, padx=10)
        self.tab_frame.grid(row=2, column=0, pady=10, padx=10)
        
        self.main_frame.columnconfigure(0,weight=1)
        
        # tab_frame
        direct_control_frame.grid(row=1, rowspan=1, column=0, pady=10, padx=10, sticky="")
        servo_program_frame.grid(row=2, column=0, columnspan=1,pady=10, padx=10,sticky="ew")
        #button_frame.grid(row=3, column=0, columnspan=1,pady=10, padx=10,sticky="ew")
        set_button_frame.grid(row=4, column=0, columnspan=2,pady=10, padx=10,sticky="")
        
        self.tab_frame.grid_columnconfigure(0,weight=1)
        #self.tab_frame.grid_columnconfigure(1,weight=0)
        #self.tab_frame.grid_columnconfigure(2,weight=0)
        #self.tab_frame.grid_columnconfigure(3,weight=1)
        self.tab_frame.grid_rowconfigure(3,weight=1)                

        # --- bindings
        #self.controller.bind("<Control-Right>",self.s_servo_address.invoke_buttonup)
        #self.controller.bind("<Control-Left>",self.s_servo_address.invoke_buttondown)
        #self.controller.bind("<Control-Up>",self.s_servo_channel.invoke_buttonup)
        #self.controller.bind("<Control-Down>",self.s_servo_channel.invoke_buttondown)
        self.controller.bind("<F1>",self.controller.call_helppage)
        self.controller.bind("<Alt-F4>",self.cancel)
        self.controller.bind("<Control-o>",self.led_off)

 
    def cancel(self,_event=None):
        try:
            pass
        except:
            pass

        #self.setConfigData("lastLed"     , self.v_servo_address.get())
        #self.setConfigData("lastservo_channel", self.v_servo_channel.get())
        #self.setParamData("Lednum"   , self.v_servo_address.get())
        #self.setParamData("servo_channel" , self.v_servo_channel.get())
        
    def tabselected(self):
        self.controller.currentTabClass = self.tabClassName
        self.controller.send_to_ARDUINO("#BEGIN")
        time.sleep(ARDUINO_WAITTIME)
        #self.controller.bind("<Control-Down>",self.s_servo_address.invoke_buttonup)
        #self.controller.bind("<Control-Up>",self.s_servo_address.invoke_buttondown)
        #self.controller.bind("<Control-Right>",self.s_servo_channel.invoke_buttonup)
        #self.controller.bind("<Control-Left>",self.s_servo_channel.invoke_buttondown)

        self.controller.bind("<F1>",self.controller.call_helppage)
        self.controller.bind("<Alt-F4>",self.cancel)
        
    def tabunselected(self):
        self.controller.send_to_ARDUINO("#END")
        time.sleep(ARDUINO_WAITTIME)          
        pass
        
        logging.info(self.tabname)
        pass        

    def getConfigData(self, key):
        return self.controller.getConfigData(key)
    
    def readConfigData(self):
        self.controller.readConfigData()
        
    def setConfigData(self,key, value):
        self.controller.setConfigData(key, value)

    def setParamData(self,key, value):
        self.controller.setParamData(key, value)

    def connect(self):
        pass

    def disconnect(self):
        pass
            
    @staticmethod
    def _select_all_spinbox(event):
        """Select all entry content."""
        event.widget.selection('range', 0, 'end')
        return "break"

    @staticmethod
    def _select_all_entry(event):
        """Select all entry content."""
        event.widget.selection_range(0, 'end')
        return "break"

    def _unfocus(self, event):
        """Unfocus palette items when click on bar or square."""
        w = self.focus_get()
        if w != self and 'spinbox' not in str(w) and 'entry' not in str(w):
            self.focus_set()
            
    def servo_scale_focus_set(self,event=None):
        self.servo_scale.focus_set()

    def _update_servo_channel(self, servo_address, servo_channel, position):
        if servo_channel == 0:
            self._update_servos(servo_address, position, 0, 0)
        elif servo_address == 1:
            self._update_servos(servo_address, 0, position, 0)
        else:
            self._update_servos(servo_address, 0, 0, position)

    def servo_pos_inc(self,event):
        #var = self.servo_pos_var.get()
        #self.servo_pos_var.set(var + 1)
        pass
        
    def servo_pos_dec(self,event):
        #var = self.servo_pos_var.get()
        #self.servo_pos_var.set(var - 1)
        pass
            
    def _update_servo_position(self, position):
        position_int=int(position)
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")
        self._update_servo_channel(servo_address, servo_channel, position_int)
        
    def _update_servo_speed(self, event=None):
        speed=self.v_speed_0.get()
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")        
        self._update_servos(servo_address, speed, speed, speed)

    def _get_servo_channel_code(self, servo_channel):
        # select the right servo
        if servo_channel == "0":
            return 225
        elif servo_channel == "1":
            return 230
        else:
            return 235
        
    def _start_set_servo_speed(self, event=None):
        # select the right servo
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")
        servo_channel_code = self._get_servo_channel_code(servo_channel)
        
        #send code to ARDUINO
        self._update_servos(servo_address, servo_channel_code, servo_channel_code, servo_channel_code)
        
        # send "start speed setting"
        self._update_servos(servo_address, 245, 245, 245)
        self.sss_label.config(background="#ffff05",text="Servo Geschwindigkeit hier einstellen")

        # send current speed
        speed=int(self.v_speed_0.get())
        self._update_servos(servo_address, speed, speed, speed)       
 
    def _end_set_servo_speed(self, event=None):
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")
        servo_channel_code = self._get_servo_channel_code(servo_channel)
        
        #send "end"-code to ARDUINO
        self._update_servos(servo_address, 254, 254, 254)
        
        #send "back to normal"-code to ARDUINO
        self._update_servos(servo_address, 0, 0, 0)
        self.sss_label.config(background="white",text=" ")

    def _start_set_min_max_pos(self, event=None):
        # select the right servo
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")
        servo_channel_code = self._get_servo_channel_code(servo_channel)
        
        #send code to ARDUINO
        self._update_servos(servo_address, servo_channel_code, servo_channel_code, servo_channel_code)
        
        # send "start pos setting"
        self._update_servos(servo_address, 240, 240, 240)
        
        # send "start min pos setting"
        self._update_servos(servo_address, 250, 250, 250)
        
        self.ssp_label2.config(background="#ffff05",text="Bewege den Servo zur Min Position mit den <<,<,>,>> Tastern")
        
    def _save_min_max_pos(self, event=None):
        
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")
        servo_channel_code = self._get_servo_channel_code(servo_channel)        
        
        if self.status == "Save Min Pos":
            self.status = "Save Max Pos"
            self.ssp_label2.config(text="Bewege den Servo zur Max Position mit den <<,<,>,>> Tastern")
            #send "save"-code to ARDUINO
            self._update_servos(servo_address, 205, 205, 205)
            self.button_start_save_mm_pos.config(text="Beende Max Pos programmieren")
        else:
            self.status = "Save Min Pos"
            self.ssp_label2.config(background="white",text="")
            self.button_start_save_mm_pos.config(text="Beende Min Pos programmieren")
        
            #send "end"-code to ARDUINO
            self._update_servos(servo_address, 254, 254, 254)
            
            #send "back to normal"-code to ARDUINO
            self._update_servos(servo_address, 0, 0, 0)
            
        
    def _update_set_servo_position(self, event=None):
        servo_position = self.servo_0.get()
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")

    def _update_servo_address(self, event=None):
        self.servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        self.servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel") 
        
    def led_off(self,_event=None):
    # switch off all LED
        self.ledhighlight = False
        message = "#L00 00 00 00 FF\n"
        self.controller.send_to_ARDUINO(message)
        #self.controller.ledtable.clear()
        
    def servo_prog_button(self,event=None,code=0):
    # send code to Servo
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")        
        self._update_servos(servo_address,code,code,code)
        
    def servo_prog_label_pressed(self,event=None,code=0):
    # send code to Servo
        event.widget.config(relief="sunken")
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")        
        self._update_servos(servo_address,code,code,code)
        
    def servo_prog_label_released(self,event=None):
    # send code to Servo
        event.widget.config(relief="raised")
        code = 0
        servo_address = self.controller.get_macroparam_val(self.tabClassName, "ServoAddress")
        servo_channel = self.controller.get_macroparam_val(self.tabClassName, "ServoChannel")        
        self._update_servos(servo_address,code,code,code)        
        
    def _update_servos(self, lednum, servo_0, servo_1, servo_2):
        message = "#L" + '{:02x}'.format(lednum) + " " + '{:02x}'.format(servo_0) + " " + '{:02x}'.format(servo_1) + " " + '{:02x}'.format(servo_2) + " " + '{:02x}'.format(1) + "\n"
        self.controller.send_to_ARDUINO(message)
        time.sleep(ARDUINO_WAITTIME)


            


